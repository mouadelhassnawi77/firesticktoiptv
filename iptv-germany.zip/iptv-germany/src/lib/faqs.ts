import { formatEuro } from "./site";
import { trial } from "./shop";

export type Faq = { q: string; a: string };

// Passe die Antworten an deine echten Konditionen an (Zahlung, Laufzeit, Geräte).
export const faqs: Faq[] = [
  {
    q: "Was ist IPTV?",
    a: "IPTV steht für Internet Protocol Television. Das Fernsehprogramm kommt über deine Internetverbindung statt über Kabel, Satellit oder Antenne. Du brauchst nur ein kompatibles Gerät, eine Player-App und deine Zugangsdaten.",
  },
  {
    q: "Wie funktioniert der 24-Stunden-Test?",
    a: `Du wählst dein Gerät und zahlst einmalig ${formatEuro(trial.price)}. Dafür bekommst du ${trial.hours} Stunden vollen Zugang mit allen Sendern und der Mediathek. Der Test endet automatisch, es entsteht kein Abo.`,
  },
  {
    q: "Auf welchen Geräten funktioniert das Abo?",
    a: "Auf Fire TV Stick, Android TV und Google TV, Samsung- und LG-Smart-TVs, Android-Handys und -Tablets, iPhone, iPad, Apple TV, MAG-Boxen sowie Windows-PCs und Macs.",
  },
  {
    q: "Welche Internetgeschwindigkeit brauche ich?",
    a: "Für HD reichen stabile 16 Mbit/s. Für 4K empfehlen wir mindestens 25 Mbit/s. Ein LAN-Kabel ist stabiler als WLAN, besonders beim Fire TV Stick und bei Smart-TVs.",
  },
  {
    q: "Verlängert sich das Abo automatisch?",
    a: "Nein. Dein Abo endet nach dem gebuchten Zeitraum. Wir erinnern dich vor dem Ablauf, und du entscheidest selbst, ob du verlängerst.",
  },
  {
    q: "Wie schnell kann ich nach der Bestellung schauen?",
    a: "In der Regel wenige Minuten nach Zahlungseingang. Du bekommst deine Zugangsdaten per WhatsApp oder E-Mail, auf Wunsch mit einer Schritt-für-Schritt-Anleitung für dein Gerät.",
  },
  {
    q: "Wie bezahle ich?",
    a: "Mit Krypto (Bitcoin oder USDT) zahlst du direkt auf unserer Bezahlseite. Bei Kredit- oder Debitkarte und PayPal öffnet sich WhatsApp mit deiner Bestellung, und wir schicken dir dort den Zahlungslink. Du zahlst einmalig, ohne versteckte Kosten.",
  },
  {
    q: "Kann ich das Abo auf mehreren Geräten nutzen?",
    a: "Du kannst die App auf mehreren Geräten installieren. Gleichzeitig schauen kannst du auf einem Gerät. Weitere gleichzeitige Verbindungen buchst du auf Anfrage dazu.",
  },
  {
    q: "Gibt es einen TV-Guide?",
    a: "Ja. Der elektronische Programmführer (EPG) zeigt dir, was gerade läuft und was als Nächstes kommt. Bei vielen Sendern kannst du verpasste Sendungen über die Aufholfunktion nachschauen.",
  },
  {
    q: "Was tun, wenn das Bild ruckelt?",
    a: "Starte Router und Gerät neu, verbinde das Gerät per LAN-Kabel oder nutze das 5-GHz-WLAN. Hilft das nicht, schreib uns per WhatsApp. Wir prüfen deine Verbindung und stellen die App optimal ein.",
  },
];
