export type Section = { heading: string; paragraphs: string[]; list?: string[] };

export type Post = {
  slug: string;
  title: string; // H1
  metaTitle: string;
  description: string;
  published: string;
  modified: string;
  readingMinutes: number;
  sections: Section[];
  related: { href: string; label: string }[]; // interne Links
};

export const posts: Post[] = [
  {
    slug: "was-ist-iptv",
    title: "Was ist IPTV? Einfach erklärt",
    metaTitle: "Was ist IPTV? Einfach erklärt für Einsteiger",
    description:
      "IPTV einfach erklärt: wie Fernsehen über das Internet funktioniert, was du brauchst und worin es sich von Kabel, Satellit und DVB-T2 unterscheidet.",
    published: "2026-09-01",
    modified: "2026-09-15",
    readingMinutes: 5,
    sections: [
      {
        heading: "IPTV in einem Satz",
        paragraphs: [
          "IPTV steht für Internet Protocol Television. Gemeint ist Fernsehen, das über deine Internetverbindung zu dir kommt, statt über Kabelanschluss, Satellitenschüssel oder Antenne.",
          "Für dich bedeutet das: Du schaust Live-TV, Filme und Serien auf jedem Gerät, das eine passende App hat. Vom Fernseher im Wohnzimmer bis zum Handy im Garten.",
        ],
      },
      {
        heading: "So funktioniert IPTV",
        paragraphs: [
          "Ein Server sendet das Programm als Datenstrom über das Internet. Eine Player-App auf deinem Gerät empfängt diesen Strom, puffert ein paar Sekunden vor und zeigt das Bild an. Welche Sender und Inhalte du siehst, legen deine Zugangsdaten fest.",
          "Anders als bei klassischen Streaming-Diensten bekommst du bei IPTV echte Live-Sender mit laufendem Programm. Dazu kommen meist eine Mediathek mit Filmen und Serien sowie ein TV-Guide.",
        ],
      },
      {
        heading: "IPTV im Vergleich zu Kabel, Satellit und DVB-T2",
        paragraphs: [
          "Der größte Unterschied ist die Flexibilität. Kabel und Satellit sind an eine Dose oder eine Schüssel gebunden. IPTV läuft überall, wo du Internet hast.",
        ],
        list: [
          "Keine Installation: kein Techniker, keine Schüssel, keine Kabeldose nötig.",
          "Jedes Gerät: Fernseher, Fire TV Stick, Handy, Tablet oder PC.",
          "Mehr Funktionen: TV-Guide, Aufholfunktion und Mediathek in einer App.",
          "Abhängig vom Internet: Die Bildqualität steht und fällt mit einer stabilen Verbindung.",
        ],
      },
      {
        heading: "Was du für IPTV brauchst",
        paragraphs: [
          "Die Voraussetzungen sind überschaubar. Wenn du schon Netflix oder YouTube auf dem Fernseher schaust, hast du fast alles zusammen.",
        ],
        list: [
          "Internet mit mindestens 16 Mbit/s für HD, 25 Mbit/s für 4K",
          "Ein kompatibles Gerät, zum Beispiel einen Fire TV Stick oder Smart-TV",
          "Eine Player-App für dein Gerät",
          "Zugangsdaten als M3U-Link oder per Xtream Codes",
        ],
      },
      {
        heading: "Fazit",
        paragraphs: [
          "IPTV macht Fernsehen unabhängig von Anschlüssen und Geräten. Wer eine stabile Internetverbindung hat, bekommt Live-TV, Mediathek und TV-Guide in einer einzigen App. Am einfachsten findest du mit einem 24-Stunden-Test heraus, ob es für dich passt.",
        ],
      },
    ],
    related: [
      { href: "/iptv-testen", label: "IPTV 24 Stunden testen" },
      { href: "/anleitung/fire-tv-stick", label: "IPTV auf dem Fire TV Stick einrichten" },
      { href: "/blog/m3u-oder-xtream-codes", label: "M3U oder Xtream Codes?" },
    ],
  },
  {
    slug: "internetgeschwindigkeit-iptv",
    title: "Welche Internetgeschwindigkeit brauche ich für IPTV?",
    metaTitle: "Internetgeschwindigkeit für IPTV: So viel Mbit/s brauchst du",
    description:
      "Wie viel Mbit/s brauchst du für IPTV in HD und 4K? Richtwerte, Speedtest-Tipps und was wirklich gegen Ruckeln hilft.",
    published: "2026-09-08",
    modified: "2026-09-15",
    readingMinutes: 4,
    sections: [
      {
        heading: "Die Richtwerte",
        paragraphs: [
          "Wie viel Bandbreite du brauchst, hängt von der Bildqualität ab. Die Werte gelten pro gleichzeitigem Stream und sollten dauerhaft stabil anliegen, nicht nur in der Spitze.",
        ],
        list: [
          "SD-Qualität: ab 6 Mbit/s",
          "HD und Full HD: ab 16 Mbit/s",
          "4K: ab 25 Mbit/s, besser 50 Mbit/s",
        ],
      },
      {
        heading: "Mehrere Geräte gleichzeitig",
        paragraphs: [
          "Schauen zwei Personen gleichzeitig auf verschiedenen Geräten, addiert sich der Bedarf. Zwei HD-Streams brauchen also rund 32 Mbit/s. Denk auch an andere Nutzer im Haushalt: Videocalls, Downloads und Konsolen-Updates teilen sich dieselbe Leitung.",
        ],
      },
      {
        heading: "So misst du richtig",
        paragraphs: [
          "Führe den Speedtest direkt auf dem Gerät aus, mit dem du schaust. Ein Test am Handy neben dem Router sagt wenig über den Fire TV Stick hinter dem Fernseher aus. Miss außerdem abends zwischen 20 und 22 Uhr, denn dann ist das Netz am stärksten ausgelastet.",
        ],
      },
      {
        heading: "Was gegen Ruckeln hilft",
        paragraphs: ["Meist liegt das Problem nicht an der gebuchten Geschwindigkeit, sondern am Weg vom Router zum Gerät."],
        list: [
          "LAN-Kabel statt WLAN, notfalls per Powerline-Adapter",
          "5-GHz-WLAN statt 2,4 GHz, wenn der Router nicht weit entfernt ist",
          "Router frei aufstellen, nicht im Schrank oder hinter dem Fernseher",
          "Router und Gerät regelmäßig neu starten",
        ],
      },
      {
        heading: "Fazit",
        paragraphs: [
          "Für die meisten Haushalte reicht ein Anschluss mit 50 Mbit/s locker aus, auch für 4K. Entscheidend ist eine stabile Verbindung bis zum Gerät. Mit unserem 24-Stunden-Test siehst du, wie es bei dir läuft.",
        ],
      },
    ],
    related: [
      { href: "/iptv-testen", label: "Verbindung 24 Stunden testen" },
      { href: "/blog/was-ist-iptv", label: "Was ist IPTV?" },
      { href: "/faq", label: "Häufige Fragen" },
    ],
  },
  {
    slug: "m3u-oder-xtream-codes",
    title: "M3U oder Xtream Codes: Welcher Zugang ist besser?",
    metaTitle: "M3U oder Xtream Codes? Unterschiede einfach erklärt",
    description:
      "M3U-Playlist oder Xtream-Codes-Login: Was ist der Unterschied, welche Variante bietet TV-Guide und Mediathek, und wann brauchst du ein MAG-Portal?",
    published: "2026-09-15",
    modified: "2026-09-15",
    readingMinutes: 4,
    sections: [
      {
        heading: "Zwei Wege zum selben Programm",
        paragraphs: [
          "Wenn du ein IPTV-Abo abschließt, bekommst du deine Zugangsdaten meist in zwei Varianten: als M3U-Link oder als Xtream-Codes-Login. Beide führen zu denselben Sendern. Sie unterscheiden sich aber darin, wie bequem die App damit arbeitet.",
        ],
      },
      {
        heading: "Was ist eine M3U-Playlist?",
        paragraphs: [
          "Eine M3U-Datei ist eine Textliste mit allen Sendern und ihren Adressen. Du fügst einen einzigen Link in die App ein, und sie liest die Liste aus. Das funktioniert mit fast jedem Player, auch mit VLC am PC.",
          "Der Nachteil: Der TV-Guide muss oft separat eingetragen werden, und große Listen laden langsamer.",
        ],
      },
      {
        heading: "Was ist Xtream Codes?",
        paragraphs: [
          "Bei Xtream Codes meldest du dich mit Server-URL, Benutzername und Passwort an. Die App fragt Sender, TV-Guide, Filme und Serien getrennt ab und sortiert sie automatisch in Kategorien.",
        ],
        list: [
          "TV-Guide wird automatisch geladen",
          "Filme und Serien erscheinen mit Cover und Beschreibung",
          "Änderungen an der Senderliste kommen ohne neuen Link bei dir an",
        ],
      },
      {
        heading: "Und das MAG-Portal?",
        paragraphs: [
          "MAG-Boxen und einige Smart-TV-Apps nutzen eine dritte Variante: eine Portal-URL, die an die MAC-Adresse deines Geräts gebunden ist. Du trägst nur die URL ein, die Freischaltung erfolgt über die Gerätekennung.",
        ],
      },
      {
        heading: "Unsere Empfehlung",
        paragraphs: [
          "Nutze Xtream Codes, wann immer deine App es unterstützt. Du bekommst den vollen Funktionsumfang mit dem geringsten Aufwand. Den M3U-Link brauchst du vor allem für VLC und ältere Player. Beide Varianten bekommst du bei uns mit jedem Abo.",
        ],
      },
    ],
    related: [
      { href: "/anleitung/android", label: "IPTV auf Android einrichten" },
      { href: "/anleitung/mag-box", label: "IPTV auf der MAG-Box einrichten" },
      { href: "/preise/12-monate", label: "IPTV-Jahresabo: 12 Monate" },
    ],
  },
];

export const getPost = (slug: string) => posts.find((p) => p.slug === slug);

export const formatDate = (iso: string) =>
  new Intl.DateTimeFormat("de-DE", { day: "numeric", month: "long", year: "numeric" }).format(new Date(iso));
