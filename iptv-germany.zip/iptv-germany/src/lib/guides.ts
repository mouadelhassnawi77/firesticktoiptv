export type Guide = {
  slug: string;
  device: string;
  title: string; // H1
  metaTitle: string;
  description: string;
  intro: string;
  needs: string[];
  steps: { title: string; text: string }[];
  tips: string[];
  updated: string; // ISO-Datum, für Sitemap und "Aktualisiert am"
};

export const guides: Guide[] = [
  {
    slug: "fire-tv-stick",
    device: "Fire TV Stick",
    title: "IPTV auf dem Fire TV Stick einrichten",
    metaTitle: "IPTV auf Fire TV Stick einrichten: Anleitung in 6 Schritten",
    description:
      "So richtest du IPTV auf dem Amazon Fire TV Stick ein: Entwickleroptionen, Downloader, Player-App und Login. Schritt für Schritt, in 10 Minuten.",
    intro:
      "Der Fire TV Stick ist das beliebteste Gerät für IPTV in Deutschland: günstig, schnell eingerichtet und mit jedem Fernseher mit HDMI-Anschluss nutzbar. Die Einrichtung dauert rund 10 Minuten.",
    needs: [
      "Fire TV Stick (ab 2. Generation, ideal: 4K oder 4K Max)",
      "Stabile Internetverbindung, mindestens 16 Mbit/s",
      "Deine Zugangsdaten (Benutzername, Passwort, Server-URL)",
    ],
    steps: [
      {
        title: "Entwickleroptionen freischalten",
        text: "Öffne Einstellungen, dann Mein Fire TV und Info. Klicke siebenmal hintereinander auf den Namen deines Geräts, bis die Meldung erscheint, dass du jetzt Entwickler bist.",
      },
      {
        title: "Downloader installieren",
        text: "Gehe zurück zum Startbildschirm, öffne die Suche und gib „Downloader“ ein. Installiere die App mit dem orangefarbenen Symbol.",
      },
      {
        title: "Installation erlauben",
        text: "Öffne Einstellungen, Mein Fire TV, Entwickleroptionen und dann Unbekannte Apps installieren. Stelle den Schalter für Downloader auf AN.",
      },
      {
        title: "Player-App installieren",
        text: "Öffne Downloader und gib den Link zur Player-App ein, den wir dir per WhatsApp schicken. Bestätige die Installation und lösche danach die Installationsdatei, um Speicher zu sparen.",
      },
      {
        title: "Zugangsdaten eintragen",
        text: "Starte die Player-App und wähle die Anmeldung per Xtream Codes. Trage Benutzername, Passwort und Server-URL genau so ein, wie du sie von uns erhalten hast.",
      },
      {
        title: "Sender laden und schauen",
        text: "Die App lädt Senderliste, TV-Guide und Mediathek. Das dauert beim ersten Start bis zu einer Minute. Danach kannst du sofort schauen.",
      },
    ],
    tips: [
      "Nutze wenn möglich einen Ethernet-Adapter für den Fire TV Stick. Das beseitigt die meisten Ruckler.",
      "Starte den Stick einmal pro Woche neu, damit der Arbeitsspeicher frei bleibt.",
      "Lege die Player-App in die erste Reihe des Startbildschirms, dann ist sie mit einem Klick erreichbar.",
    ],
    updated: "2026-09-15",
  },
  {
    slug: "smart-tv",
    device: "Samsung- und LG-Smart-TV",
    title: "IPTV auf Samsung- und LG-Smart-TV einrichten",
    metaTitle: "IPTV auf Smart TV einrichten: Samsung und LG Anleitung",
    description:
      "IPTV direkt auf dem Samsung- oder LG-Fernseher nutzen, ohne Zusatzgerät. Anleitung für Tizen und webOS: App installieren, aktivieren, Sender laden.",
    intro:
      "Auf aktuellen Samsung-Fernsehern (Tizen) und LG-Fernsehern (webOS) läuft IPTV direkt über eine App aus dem jeweiligen App-Store. Du brauchst kein zusätzliches Gerät.",
    needs: [
      "Samsung-Smart-TV ab Baujahr 2018 oder LG-Smart-TV mit webOS",
      "Internetverbindung, am besten per LAN-Kabel",
      "Deine Zugangsdaten oder deine M3U-Playlist",
    ],
    steps: [
      {
        title: "Fernseher mit dem Internet verbinden",
        text: "Verbinde den Fernseher per LAN-Kabel oder WLAN. Prüfe unter Einstellungen, Netzwerk, dass die Verbindung steht.",
      },
      {
        title: "Player-App installieren",
        text: "Öffne bei Samsung den Bereich Apps, bei LG den LG Content Store. Suche nach der Player-App, die wir dir empfehlen, und installiere sie.",
      },
      {
        title: "Gerätekennung notieren",
        text: "Manche Player-Apps zeigen beim ersten Start eine MAC-Adresse oder Gerätekennung an. Schicke sie uns per WhatsApp, damit wir dein Abo freischalten.",
      },
      {
        title: "Zugang eintragen",
        text: "Trage deine Zugangsdaten in der App ein oder lass die Playlist von uns direkt auf dein Gerät übertragen.",
      },
      {
        title: "Fernseher neu starten",
        text: "Schalte den Fernseher einmal komplett aus und wieder ein. Danach lädt die App Senderliste und TV-Guide.",
      },
    ],
    tips: [
      "Schalte bei Samsung die Funktion Instant On aus, damit die App bei jedem Start frische Daten lädt.",
      "Ältere Fernseher ohne passende App rüstest du am einfachsten mit einem Fire TV Stick nach.",
    ],
    updated: "2026-09-15",
  },
  {
    slug: "android",
    device: "Android, Android TV und Google TV",
    title: "IPTV auf Android, Android TV und Google TV einrichten",
    metaTitle: "IPTV auf Android & Google TV einrichten: Schritt-für-Schritt",
    description:
      "IPTV auf Android-Handy, Tablet, Android-TV-Box oder Google TV einrichten. App aus dem Play Store, Login per Xtream Codes, fertig.",
    intro:
      "Auf Android-Geräten ist IPTV am schnellsten eingerichtet, denn passende Player-Apps gibt es direkt im Google Play Store. Das gilt für Handys, Tablets, Android-TV-Boxen und Fernseher mit Google TV.",
    needs: [
      "Android-Gerät ab Android 8",
      "Google-Konto für den Play Store",
      "Deine Zugangsdaten",
    ],
    steps: [
      {
        title: "Play Store öffnen",
        text: "Öffne den Google Play Store auf deinem Gerät und suche nach der Player-App, die wir dir empfehlen.",
      },
      {
        title: "App installieren",
        text: "Tippe auf Installieren und warte, bis die App fertig ist. Öffne sie anschließend.",
      },
      {
        title: "Anmeldung wählen",
        text: "Wähle in der App die Anmeldung per Xtream Codes. Das ist die einfachste Variante mit TV-Guide und Mediathek.",
      },
      {
        title: "Zugangsdaten eintragen",
        text: "Trage einen beliebigen Namen für das Profil ein, dann Benutzername, Passwort und Server-URL. Achte auf Groß- und Kleinschreibung.",
      },
      {
        title: "Sender laden",
        text: "Die App lädt Senderliste, TV-Guide und Mediathek. Danach kannst du sofort schauen.",
      },
    ],
    tips: [
      "Auf dem Handy sparst du mobiles Datenvolumen, wenn du in der App eine niedrigere Qualität einstellst.",
      "Android-TV-Boxen verbindest du am besten per LAN-Kabel.",
    ],
    updated: "2026-09-15",
  },
  {
    slug: "iphone-ipad",
    device: "iPhone, iPad und Apple TV",
    title: "IPTV auf iPhone, iPad und Apple TV einrichten",
    metaTitle: "IPTV auf iPhone, iPad & Apple TV einrichten: Anleitung",
    description:
      "IPTV auf iPhone, iPad und Apple TV nutzen: passende Player-App aus dem App Store, Login und Tipps für ruckelfreies Streaming.",
    intro:
      "Auf Apple-Geräten nutzt du IPTV über eine Player-App aus dem App Store. Die Einrichtung ist auf iPhone, iPad und Apple TV fast identisch.",
    needs: [
      "iPhone oder iPad ab iOS 15, Apple TV ab tvOS 15",
      "Apple-ID für den App Store",
      "Deine Zugangsdaten oder deine M3U-Playlist",
    ],
    steps: [
      {
        title: "Player-App laden",
        text: "Öffne den App Store und installiere die Player-App, die wir dir empfehlen. Manche Apps kosten einmalig ein paar Euro.",
      },
      {
        title: "Neue Playlist anlegen",
        text: "Öffne die App und tippe auf Playlist hinzufügen. Wähle Xtream Codes oder M3U, je nachdem, welche Zugangsdaten du bekommen hast.",
      },
      {
        title: "Daten eintragen",
        text: "Trage Server-URL, Benutzername und Passwort ein oder füge den M3U-Link ein. Speichere die Playlist.",
      },
      {
        title: "Schauen",
        text: "Die App lädt Senderliste und TV-Guide. Wähle einen Sender und leg los.",
      },
    ],
    tips: [
      "Auf dem Apple TV lohnt sich eine Verbindung per LAN-Kabel für 4K-Inhalte.",
      "Mit AirPlay spiegelst du das Bild vom iPhone auf einen kompatiblen Fernseher.",
    ],
    updated: "2026-09-15",
  },
  {
    slug: "mag-box",
    device: "MAG-Box",
    title: "IPTV auf der MAG-Box einrichten",
    metaTitle: "IPTV auf MAG-Box einrichten: Portal-URL & MAC-Adresse",
    description:
      "MAG-Box für IPTV einrichten: MAC-Adresse finden, Portal-URL eintragen, neu starten. Anleitung für MAG 322, 424, 524 und neuere Modelle.",
    intro:
      "MAG-Boxen sind reine IPTV-Receiver und besonders einfach zu bedienen. Die Freischaltung erfolgt über die MAC-Adresse der Box und eine Portal-URL.",
    needs: [
      "MAG-Box (z. B. MAG 322, 424, 524 oder neuer)",
      "Internetverbindung per LAN-Kabel",
      "Die Portal-URL, die wir dir schicken",
    ],
    steps: [
      {
        title: "MAC-Adresse ablesen",
        text: "Die MAC-Adresse steht auf dem Aufkleber unter der Box und beginnt mit 00:1A:79. Schicke sie uns per WhatsApp.",
      },
      {
        title: "Einstellungen öffnen",
        text: "Schalte die Box ein und öffne Einstellungen, dann Systemeinstellungen und Server.",
      },
      {
        title: "Portal eintragen",
        text: "Öffne Portale. Trage bei Portal 1 einen Namen und die Portal-URL ein, die du von uns bekommen hast. Speichere mit OK.",
      },
      {
        title: "Box neu starten",
        text: "Gehe zurück und wähle Neustart. Die Box verbindet sich mit dem Portal und lädt die Senderliste.",
      },
    ],
    tips: [
      "Halte die Firmware der Box aktuell. Das Update findest du unter Systemeinstellungen, Software-Update.",
      "Bei „Portal nicht erreichbar“ prüfe zuerst, ob die URL exakt stimmt, inklusive Schrägstrich am Ende.",
    ],
    updated: "2026-09-15",
  },
  {
    slug: "windows-mac",
    device: "Windows-PC und Mac",
    title: "IPTV auf Windows-PC und Mac einrichten",
    metaTitle: "IPTV auf PC & Mac schauen: Anleitung mit VLC und Player-App",
    description:
      "IPTV am Computer schauen: mit VLC über den M3U-Link oder mit einer Player-App für Windows und macOS. Einfache Anleitung.",
    intro:
      "Am Computer schaust du IPTV am schnellsten mit dem kostenlosen VLC Media Player. Für TV-Guide und Mediathek eignet sich eine eigene Player-App besser.",
    needs: [
      "Windows 10 oder neuer, macOS 12 oder neuer",
      "VLC Media Player oder eine Player-App",
      "Deinen M3U-Link",
    ],
    steps: [
      {
        title: "VLC installieren",
        text: "Lade den VLC Media Player von der offiziellen Website videolan.org herunter und installiere ihn.",
      },
      {
        title: "Netzwerkstream öffnen",
        text: "Öffne VLC und wähle im Menü Medien den Punkt Netzwerkstream öffnen. Auf dem Mac heißt der Punkt Ablage, Netzwerk öffnen.",
      },
      {
        title: "M3U-Link einfügen",
        text: "Füge deinen M3U-Link in das Feld ein und klicke auf Wiedergabe.",
      },
      {
        title: "Sender wählen",
        text: "Öffne die Wiedergabeliste mit Strg+L (Mac: Cmd+L). Dort findest du alle Sender und startest sie per Doppelklick.",
      },
    ],
    tips: [
      "VLC zeigt keinen TV-Guide an. Wenn du EPG und Mediathek möchtest, empfehlen wir dir eine Player-App für Windows oder macOS.",
      "Mit einem HDMI-Kabel bringst du das Bild vom Laptop auf den Fernseher.",
    ],
    updated: "2026-09-15",
  },
];

export const getGuide = (slug: string) => guides.find((g) => g.slug === slug);
