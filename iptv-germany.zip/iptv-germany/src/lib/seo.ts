import type { Metadata } from "next";
import { site, absoluteUrl, isIndexable } from "./site";
import { plans, type Product } from "./shop";

type PageMeta = {
  title: string;
  description: string;
  path: string;
  noindex?: boolean;
  /** true = Title ohne Marken-Suffix aus dem Template (z. B. Startseite) */
  absoluteTitle?: boolean;
  type?: "website" | "article";
  publishedTime?: string;
  modifiedTime?: string;
};

/**
 * Einheitliche Metadaten pro Seite: Title, Description, Canonical, Open Graph, Twitter, Robots.
 * Das OG-Bild kommt aus app/opengraph-image.tsx und wird hier explizit gesetzt,
 * damit es beim Überschreiben von openGraph nicht verloren geht.
 */
export function pageMetadata({
  title,
  description,
  path,
  noindex,
  absoluteTitle,
  type = "website",
  publishedTime,
  modifiedTime,
}: PageMeta): Metadata {
  const ogImage = { url: "/opengraph-image", width: 1200, height: 630, alt: site.name };
  return {
    title: absoluteTitle ? { absolute: title } : title,
    description,
    alternates: { canonical: path },
    openGraph: {
      title,
      description,
      url: path,
      siteName: site.name,
      locale: site.locale,
      type,
      images: [ogImage],
      ...(type === "article" ? { publishedTime, modifiedTime } : {}),
    },
    twitter: { card: "summary_large_image", title, description, images: [ogImage.url] },
    robots: noindex || !isIndexable ? { index: false, follow: true } : { index: true, follow: true },
  };
}

const orgId = `${site.url}/#organization`;
const websiteId = `${site.url}/#website`;

export function organizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": orgId,
    name: site.name,
    legalName: site.legalName,
    url: site.url,
    logo: absoluteUrl("/icon.svg"),
    email: site.email,
    address: {
      "@type": "PostalAddress",
      streetAddress: site.address.street,
      postalCode: site.address.zip,
      addressLocality: site.address.city,
      addressCountry: site.address.country,
    },
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "customer support",
      email: site.email,
      availableLanguage: ["German", "English"],
      areaServed: "DE",
    },
    ...(site.social.length ? { sameAs: site.social } : {}),
  };
}

export function websiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": websiteId,
    url: site.url,
    name: site.name,
    inLanguage: site.language,
    publisher: { "@id": orgId },
  };
}

export function breadcrumbSchema(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.name,
      item: absoluteUrl(item.path),
    })),
  };
}

export function faqSchema(faqs: { q: string; a: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
}

const offer = (p: Product) => ({
  "@type": "Offer",
  name: p.name,
  price: p.price.toFixed(2),
  priceCurrency: "EUR",
  availability: "https://schema.org/InStock",
  priceValidUntil: `${new Date().getFullYear() + 1}-12-31`,
  url: absoluteUrl(p.page ?? "/preise"),
  seller: { "@id": orgId },
});

/** Alle Abos als ein Product mit AggregateOffer (Preisspanne im Snippet). Keine erfundenen Bewertungen. */
export function productSchema() {
  const prices = plans.map((p) => p.price);
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    "@id": `${site.url}/#product`,
    name: `${site.name} IPTV-Abo`,
    description: site.description,
    image: absoluteUrl("/opengraph-image"),
    brand: { "@type": "Brand", name: site.name },
    offers: {
      "@type": "AggregateOffer",
      priceCurrency: "EUR",
      lowPrice: Math.min(...prices).toFixed(2),
      highPrice: Math.max(...prices).toFixed(2),
      offerCount: plans.length,
      offers: plans.map(offer),
    },
  };
}

/** Ein einzelnes Paket (eigene Seite pro Laufzeit, Test-Seite) */
export function singleProductSchema(p: Product, name: string, description: string) {
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    name,
    description,
    image: absoluteUrl("/opengraph-image"),
    brand: { "@type": "Brand", name: site.name },
    offers: offer(p),
  };
}

export function articleSchema(a: {
  title: string;
  description: string;
  path: string;
  published: string;
  modified: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: a.title,
    description: a.description,
    mainEntityOfPage: absoluteUrl(a.path),
    image: absoluteUrl("/opengraph-image"),
    datePublished: a.published,
    dateModified: a.modified,
    inLanguage: site.language,
    author: { "@id": orgId },
    publisher: { "@id": orgId },
  };
}

export function howToSchema(g: { title: string; description: string; path: string; steps: { title: string; text: string }[] }) {
  return {
    "@context": "https://schema.org",
    "@type": "HowTo",
    name: g.title,
    description: g.description,
    inLanguage: site.language,
    url: absoluteUrl(g.path),
    step: g.steps.map((s, i) => ({
      "@type": "HowToStep",
      position: i + 1,
      name: s.title,
      text: s.text,
    })),
  };
}
