/**
 * Shop-Konfiguration: Pakete, Geräte, Zahlungsarten, Krypto-Wallets.
 * Diese Datei wird auch im Browser genutzt (Bestell-Popup, Checkout) – keine Geheimnisse hier ablegen.
 */

export type Product = {
  id: string;
  name: string; // Anzeigename
  months: number; // 0 = Test
  hours?: number;
  price: number; // Gesamtpreis in EUR, einmalig
  popular?: boolean;
  page?: string; // eigene SEO-Seite
};

export const plans: Product[] = [
  { id: "3-monate", name: "3 Monate", months: 3, price: 29, page: "/preise/3-monate" },
  { id: "6-monate", name: "6 Monate", months: 6, price: 39, page: "/preise/6-monate" },
  { id: "12-monate", name: "12 Monate", months: 12, price: 59, popular: true, page: "/preise/12-monate" },
];

export const trial: Product = { id: "test-24h", name: "24-Stunden-Test", months: 0, hours: 24, price: 1.99, page: "/iptv-testen" };

export const products: Product[] = [trial, ...plans];
export const getProduct = (id: string) => products.find((p) => p.id === id);
export const popularPlan = plans.find((p) => p.popular) ?? plans[plans.length - 1];

export const planFeatures = [
  "Alle Sender und die komplette Mediathek",
  "HD, Full HD und 4K, wo verfügbar",
  "TV-Guide (EPG) und Aufholfunktion",
  "1 Gerät gleichzeitig, weitere auf Anfrage",
  "Einrichtung und Support per WhatsApp",
];

/** Monatspreis und Ersparnis gegenüber dem kürzesten Abo */
export const monthly = (p: Product) => (p.months ? p.price / p.months : p.price);
export const savingsPercent = (p: Product) => {
  const base = monthly(plans[0]);
  return Math.round((1 - monthly(p) / base) * 100);
};
export const lowestMonthly = Math.min(...plans.map(monthly));

/** Geräte-IDs = Slugs der Anleitungen, damit Popup und Anleitung zusammenpassen */
export const devices = [
  { id: "fire-tv-stick", label: "Fire TV Stick" },
  { id: "smart-tv", label: "Smart TV (Samsung, LG)" },
  { id: "android", label: "Android / Google TV" },
  { id: "iphone-ipad", label: "iPhone, iPad, Apple TV" },
  { id: "mag-box", label: "MAG-Box" },
  { id: "windows-mac", label: "PC / Mac" },
  { id: "anderes", label: "Anderes Gerät" },
] as const;
export const deviceLabel = (id: string) => devices.find((d) => d.id === id)?.label ?? id;

export const paymentMethods = [
  { id: "crypto", label: "Krypto (BTC, USDT)", hint: "Du zahlst direkt auf der nächsten Seite. Zugang nach Zahlungseingang." },
  { id: "card", label: "Kredit- oder Debitkarte", hint: "WhatsApp öffnet sich mit deiner Bestellung. Du bekommst dort den Zahlungslink." },
  { id: "paypal", label: "PayPal", hint: "WhatsApp öffnet sich mit deiner Bestellung. Du bekommst dort den Zahlungslink." },
] as const;
export type PaymentId = (typeof paymentMethods)[number]["id"];
export const paymentLabel = (id: string) => paymentMethods.find((p) => p.id === id)?.label ?? id;

/**
 * Krypto-Wallets für den Checkout. Adresse leer = diese Währung wird im Checkout als
 * "nicht verfügbar" angezeigt und der Kunde auf WhatsApp umgeleitet (nichts geht verloren).
 */
export const cryptoWallets = [
  {
    id: "usdt-trc20",
    label: "USDT (TRC20)",
    network: "TRC20",
    coingeckoId: "tether",
    symbol: "USDT",
    decimals: 2,
    address: "", // TODO: USDT-TRC20-Adresse eintragen (beginnt mit T…)
  },
  {
    id: "btc",
    label: "Bitcoin (BTC)",
    network: "Bitcoin",
    coingeckoId: "bitcoin",
    symbol: "BTC",
    decimals: 6,
    address: "", // TODO: BTC-Adresse eintragen (bc1…)
  },
] as const;
export type WalletId = (typeof cryptoWallets)[number]["id"];

/** Bestellung, die vom Popup an den Checkout übergeben wird (sessionStorage, nie in der URL) */
export type Order = {
  id: string;
  productId: string;
  device: string;
  payment: PaymentId;
  name: string;
  email: string;
  phone?: string;
  createdAt: string;
  token?: string; // vom Server, erlaubt dem Kunden das Nachreichen der TXID
};
export const ORDER_KEY = "iptv-order";

export function newOrderId() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = new Uint8Array(6);
  crypto.getRandomValues(bytes);
  return "DE-" + Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

export function productLabel(p: Product) {
  return p.months ? `IPTV-Abo ${p.name}` : `IPTV ${p.name}`;
}
