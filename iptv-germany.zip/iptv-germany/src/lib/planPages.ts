import type { Faq } from "./faqs";

/**
 * Eigene Landingpage pro Laufzeit. Ziel-Suchbegriffe: "iptv 12 monate", "iptv jahresabo",
 * "iptv 6 monate", "iptv 3 monate". Jede Seite hat eigenen Text, damit kein Duplicate Content entsteht.
 * Preise werden nicht hier eingetragen, sondern aus shop.ts gelesen.
 */
export type PlanPage = {
  planId: string;
  slug: string;
  metaTitle: (price: string, perMonth: string) => string;
  description: (price: string, perMonth: string) => string;
  h1: (price: string) => string;
  intro: (price: string, perMonth: string) => string;
  forWhom: string[];
  faqs: Faq[];
};

export const planPages: PlanPage[] = [
  {
    planId: "12-monate",
    slug: "12-monate",
    metaTitle: (price, perMonth) => `IPTV Jahresabo: 12 Monate für ${price} (${perMonth}/Monat)`,
    description: (price, perMonth) =>
      `IPTV 12 Monate für ${price}, nur ${perMonth} im Monat: alle Sender, Filme und Serien in HD und 4K. Einmal zahlen, ein Jahr schauen, keine automatische Verlängerung.`,
    h1: (price) => `IPTV Jahresabo: 12 Monate für ${price}`,
    intro: (price, perMonth) =>
      `Das Jahresabo ist unser beliebtestes Paket. Du zahlst einmal ${price} und schaust zwölf Monate lang, das sind ${perMonth} im Monat. Danach endet das Abo von selbst.`,
    forWhom: [
      "Du hast den Test gemacht oder IPTV schon genutzt und weißt, dass es bei dir stabil läuft.",
      "Du willst dich ein Jahr lang nicht um Verlängerungen kümmern.",
      "Du willst den niedrigsten Monatspreis, ohne dich an einen Vertrag mit automatischer Verlängerung zu binden.",
    ],
    faqs: [
      {
        q: "Verlängert sich das Jahresabo automatisch?",
        a: "Nein. Nach zwölf Monaten endet der Zugang. Wir erinnern dich rechtzeitig, und du entscheidest selbst, ob du verlängerst.",
      },
      {
        q: "Kann ich von 3 oder 6 Monaten auf das Jahresabo wechseln?",
        a: "Ja. Bestelle das Jahresabo einfach vor Ablauf deines aktuellen Pakets. Wir verlängern deinen bestehenden Zugang, du musst nichts neu einrichten.",
      },
      {
        q: "Was ist, wenn ich im Laufe des Jahres das Gerät wechsle?",
        a: "Du trägst deine Zugangsdaten einfach auf dem neuen Gerät ein. Die passende Anleitung findest du auf unserer Seite, bei Fragen hilft der Support per WhatsApp.",
      },
    ],
  },
  {
    planId: "6-monate",
    slug: "6-monate",
    metaTitle: (price, perMonth) => `IPTV 6 Monate für ${price} (${perMonth}/Monat)`,
    description: (price, perMonth) =>
      `IPTV-Abo für 6 Monate: ${price} einmalig, ${perMonth} im Monat. Alle Sender, Mediathek und TV-Guide. Keine automatische Verlängerung.`,
    h1: (price) => `IPTV 6 Monate für ${price}`,
    intro: (price, perMonth) =>
      `Ein halbes Jahr IPTV für ${price}, also ${perMonth} im Monat. Ein guter Mittelweg, wenn du länger schauen willst, dich aber noch nicht für ein ganzes Jahr festlegen möchtest.`,
    forWhom: [
      "Du schaust regelmäßig, zum Beispiel die ganze Fußball-Hinrunde oder eine Serienstaffel am Stück.",
      "Du willst deutlich günstiger schauen als mit dem 3-Monats-Paket.",
    ],
    faqs: [
      {
        q: "Lohnt sich das 6-Monats-Paket gegenüber 3 Monaten?",
        a: "Ja, wenn du länger als drei Monate schauen willst. Der Monatspreis ist deutlich niedriger, und du musst nur einmal bestellen.",
      },
      {
        q: "Kann ich später auf 12 Monate verlängern?",
        a: "Ja. Bestelle das Jahresabo vor Ablauf, und wir verlängern deinen bestehenden Zugang.",
      },
    ],
  },
  {
    planId: "3-monate",
    slug: "3-monate",
    metaTitle: (price, perMonth) => `IPTV 3 Monate für ${price}: Abo zum Einstieg`,
    description: (price, perMonth) =>
      `IPTV für 3 Monate: ${price} einmalig (${perMonth} im Monat). Alle Sender und die Mediathek, ideal zum Einstieg. Keine automatische Verlängerung.`,
    h1: (price) => `IPTV 3 Monate für ${price}`,
    intro: (price, perMonth) =>
      `Das kürzeste Paket: drei Monate IPTV für ${price}, ${perMonth} im Monat. Ideal, wenn du nach dem Test erst einmal eine Saison lang schauen willst.`,
    forWhom: [
      "Du willst IPTV über einen längeren Zeitraum ausprobieren, bevor du ein Jahr buchst.",
      "Du brauchst den Zugang nur für eine bestimmte Zeit, etwa für ein Turnier oder einen Urlaub.",
    ],
    faqs: [
      {
        q: "Bekomme ich mit 3 Monaten weniger Sender?",
        a: "Nein. Alle Pakete haben denselben Umfang. Unterschiedlich sind nur Laufzeit und Monatspreis.",
      },
      {
        q: "Was passiert nach drei Monaten?",
        a: "Der Zugang endet automatisch. Möchtest du weiterschauen, bestellst du einfach ein neues Paket, am günstigsten ist das Jahresabo.",
      },
    ],
  },
];

export const getPlanPage = (slug: string) => planPages.find((p) => p.slug === slug);
