/**
 * Zentrale Konfiguration – alles, was du pro Projekt anpassen musst, steht hier.
 * Marke, Domain, Kontakt und Firmendaten fürs Impressum.
 * Pakete, Preise, Geräte und Krypto-Wallets stehen in src/lib/shop.ts.
 */

/**
 * Domain-Reihenfolge: 1) NEXT_PUBLIC_SITE_URL (in Vercel setzen)
 * 2) Produktions-Domain, die Vercel automatisch liefert  3) Platzhalter.
 */
function resolveSiteUrl() {
  const fromEnv = process.env.NEXT_PUBLIC_SITE_URL;
  const vercelProd = process.env.VERCEL_PROJECT_PRODUCTION_URL;
  const url = fromEnv || (vercelProd ? `https://${vercelProd}` : "https://www.deine-domain.de");
  return url.replace(/\/$/, "");
}

/**
 * Nur das Production-Deployment darf indexiert werden.
 * Preview-Deployments (jeder Branch/PR auf *.vercel.app) bekommen noindex + robots.txt Disallow,
 * damit Google keine Duplikate deiner Seite findet. Lokal (ohne VERCEL_ENV) gilt: indexierbar.
 */
import { lowestMonthly, trial } from "./shop";

const eur = new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" });
export const formatEuro = (value: number) => eur.format(value);

export const isIndexable = process.env.VERCEL_ENV ? process.env.VERCEL_ENV === "production" : true;

export const site = {
  name: "IPTV Germany",
  supportName: "IPTV Germany Support", // so erscheint ihr gegenüber Kunden in allen WhatsApp-Nachrichten
  legalName: "Firmenname GmbH", // exakt wie im Handelsregister
  url: resolveSiteUrl(),
  locale: "de_DE",
  language: "de-DE",
  description:
    `IPTV-Abo für Deutschland: Live-TV, Filme und Serien in HD und 4K auf Fire TV Stick, Smart TV, Handy und PC. Ab ${formatEuro(lowestMonthly)} im Monat, 24 Stunden testen für ${formatEuro(trial.price)}.`,
  // Angebotsdaten – passe sie an dein echtes Angebot an
  channelCount: "18.000+",
  vodCount: "60.000+",
  // Kontakt
  whatsapp: "212760605268", // Bestell- und Support-Nummer: international, ohne + und ohne Leerzeichen
  email: "support@deine-domain.de",
  supportHours: "Täglich 9:00 bis 23:00 Uhr",
  // Firmendaten für Impressum (§ 5 DDG) und Schema
  address: {
    street: "Musterstraße 1",
    zip: "10115",
    city: "Berlin",
    country: "DE",
  },
  managingDirector: "Vorname Nachname",
  register: "Amtsgericht Berlin-Charlottenburg, HRB 000000",
  vatId: "DE000000000",
  social: [] as string[], // z. B. ["https://www.facebook.com/…", "https://t.me/…"]
} as const;

export const absoluteUrl = (path = "/") => `${site.url}${path === "/" ? "" : path}`;

export function whatsappLink(message: string) {
  return `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(message)}`;
}

export const mainNav = [
  { href: "/preise", label: "Preise" },
  { href: "/anleitung", label: "Anleitungen" },
  { href: "/blog", label: "Ratgeber" },
  { href: "/faq", label: "FAQ" },
  { href: "/kontakt", label: "Kontakt" },
];
