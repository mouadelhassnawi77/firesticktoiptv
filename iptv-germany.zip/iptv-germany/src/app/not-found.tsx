import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Seite nicht gefunden",
  robots: { index: false, follow: true },
};

// Liegt außerhalb der (site)-Gruppe, deshalb Kopf und Fuß hier direkt
export default function NotFound() {
  return (
    <>
      <Header />
      <main id="inhalt" className="wrap page-head" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
        <h1>Diese Seite gibt es nicht</h1>
        <p className="lead">Der Link ist veraltet oder falsch geschrieben. Hier geht es weiter:</p>
        <ul className="link-list" style={{ maxWidth: "28rem" }}>
          <li><Link href="/">Startseite</Link></li>
          <li><Link href="/preise">Preise</Link></li>
          <li><Link href="/anleitung">Anleitungen</Link></li>
          <li><Link href="/faq">Häufige Fragen</Link></li>
        </ul>
      </main>
      <Footer />
    </>
  );
}
