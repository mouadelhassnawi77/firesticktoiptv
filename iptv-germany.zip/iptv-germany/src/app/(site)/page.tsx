import type { Metadata } from "next";
import Link from "next/link";
import Epg from "@/components/Epg";
import Pricing from "@/components/Pricing";
import FaqList from "@/components/FaqList";
import DeviceList from "@/components/DeviceList";
import CtaBand from "@/components/CtaBand";
import { faqs } from "@/lib/faqs";
import OrderButton from "@/components/order/OrderButton";
import { site, formatEuro } from "@/lib/site";
import { lowestMonthly, trial } from "@/lib/shop";
import { pageMetadata } from "@/lib/seo";

const minMonthly = lowestMonthly;

export const metadata: Metadata = pageMetadata({
  title: `IPTV Deutschland: Abo für Live-TV, Filme & Serien | ${site.name}`,
  description: `IPTV-Abo für Deutschland ab ${formatEuro(minMonthly)} im Monat: ${site.channelCount} Sender, Filme und Serien in HD und 4K auf Fire TV Stick, Smart TV und Handy. 24 h testen für ${formatEuro(trial.price)}.`,
  path: "/",
  absoluteTitle: true,
});

const features = [
  {
    title: "Live-TV und Mediathek",
    text: `${site.channelCount} Sender aus Deutschland und aller Welt, dazu ${site.vodCount} Filme und Serien auf Abruf.`,
  },
  {
    title: "Stabil in HD und 4K",
    text: "Server mit Reserven für den Samstagabend. Die Bildqualität passt sich deiner Verbindung an.",
  },
  {
    title: "TV-Guide und Aufholen",
    text: "Sieh, was gerade läuft, und schau verpasste Sendungen bei vielen Sendern nach.",
  },
  {
    title: "Hilfe per WhatsApp",
    text: `Wir richten dein Gerät gemeinsam mit dir ein. ${site.supportHours}, auf Deutsch.`,
  },
];

export default function HomePage() {
  return (
    <>
      <section className="hero">
        <div className="wrap">
          <div>
            <h1>IPTV für Deutschland auf jedem Gerät</h1>
            <p className="hero-lead">
              Live-TV, Filme und Serien auf Fire TV Stick, Smart TV, Handy und PC. Ein Abo, keine Schüssel, kein
              Kabelanschluss.
            </p>
            <div className="hero-actions">
              <Link href="#preise" className="btn btn-primary">
                Pakete ansehen
              </Link>
              <OrderButton productId={trial.id} className="btn btn-ghost">
                {trial.hours} Stunden testen für {formatEuro(trial.price)}
              </OrderButton>
            </div>
            <p className="hero-note">
              Ab {formatEuro(minMonthly)} im Monat. Keine automatische Verlängerung.
            </p>
          </div>
          <Epg />
        </div>
      </section>

      <section className="section" aria-labelledby="features">
        <div className="wrap split">
          <div>
            <h2 id="features">Was dein IPTV-Abo kann</h2>
            <p className="muted">
              Alles in einer App: Sender, TV-Guide und Mediathek. Du installierst einmal und schaust auf dem Gerät, das
              gerade in der Nähe ist.
            </p>
          </div>
          <ul className="feature-list">
            {features.map((f) => (
              <li key={f.title}>
                <h3>{f.title}</h3>
                <p>{f.text}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section" aria-labelledby="preise">
        <div className="wrap">
          <div className="section-intro">
            <h2 id="preise">IPTV Preise und Laufzeiten</h2>
            <p>
              Jede Laufzeit enthält denselben Umfang. Das Jahresabo ist mit {formatEuro(minMonthly)} im Monat am
              günstigsten und bei unseren Kunden am beliebtesten.
            </p>
          </div>
          <Pricing headingLevel={3} />
        </div>
      </section>

      <section className="section" aria-labelledby="start">
        <div className="wrap">
          <div className="section-intro">
            <h2 id="start">In drei Schritten startklar</h2>
          </div>
          <ol className="steps is-row">
            <li>
              <h3>Paket wählen</h3>
              <p>Wähle Laufzeit, Gerät und Zahlungsart. Mit Krypto zahlst du direkt, mit Karte oder PayPal über WhatsApp.</p>
            </li>
            <li>
              <h3>App installieren</h3>
              <p>Folge der Anleitung für dein Gerät. Das dauert etwa 10 Minuten.</p>
            </li>
            <li>
              <h3>Einschalten</h3>
              <p>Zugangsdaten eintragen, Sender laden, schauen. Wir helfen per WhatsApp, falls es hakt.</p>
            </li>
          </ol>
        </div>
      </section>

      <section className="section" aria-labelledby="geraete">
        <div className="wrap">
          <div className="section-intro">
            <h2 id="geraete">IPTV einrichten auf deinem Gerät</h2>
            <p>Für jedes Gerät gibt es eine eigene Anleitung mit allen Schritten.</p>
          </div>
          <DeviceList />
        </div>
      </section>

      <section className="section" aria-labelledby="fragen">
        <div className="wrap split">
          <div>
            <h2 id="fragen">Häufige Fragen</h2>
            <p className="muted">
              Weitere Antworten findest du auf der <Link href="/faq">FAQ-Seite</Link>, oder du schreibst uns direkt.
            </p>
          </div>
          <FaqList items={faqs.slice(0, 5)} />
        </div>
      </section>

      <CtaBand />
    </>
  );
}
