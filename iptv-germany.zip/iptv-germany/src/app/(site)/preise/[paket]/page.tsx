import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Breadcrumbs from "@/components/Breadcrumbs";
import CtaBand from "@/components/CtaBand";
import FaqList from "@/components/FaqList";
import JsonLd from "@/components/JsonLd";
import OrderButton from "@/components/order/OrderButton";
import { planPages, getPlanPage } from "@/lib/planPages";
import { formatEuro } from "@/lib/site";
import { getProduct, plans, planFeatures, monthly, savingsPercent, trial } from "@/lib/shop";
import { pageMetadata, singleProductSchema, faqSchema } from "@/lib/seo";

type Props = { params: Promise<{ paket: string }> };

export const dynamicParams = false;
export function generateStaticParams() {
  return planPages.map((p) => ({ paket: p.slug }));
}

function resolve(slug: string) {
  const page = getPlanPage(slug);
  const product = page ? getProduct(page.planId) : undefined;
  if (!page || !product) return null;
  return { page, product, price: formatEuro(product.price), perMonth: formatEuro(monthly(product)) };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const r = resolve((await params).paket);
  if (!r) return {};
  return pageMetadata({
    title: r.page.metaTitle(r.price, r.perMonth),
    description: r.page.description(r.price, r.perMonth),
    path: `/preise/${r.page.slug}`,
  });
}

export default async function PlanPage({ params }: Props) {
  const r = resolve((await params).paket);
  if (!r) notFound();
  const { page, product, price, perMonth } = r;
  const path = `/preise/${page.slug}`;
  const save = savingsPercent(product);

  return (
    <>
      <div className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
        <div className="page-head" style={{ paddingInline: 0 }}>
          <Breadcrumbs
            items={[
              { name: "Preise", path: "/preise" },
              { name: `IPTV ${product.name}`, path },
            ]}
          />
          {product.popular && <p className="plan-badge">Beliebteste Wahl</p>}
          <h1>{page.h1(price)}</h1>
          <p className="lead">{page.intro(price, perMonth)}</p>
        </div>

        <div className="two-col">
          <article className="prose">
            <h2>Das ist im Paket enthalten</h2>
            <ul>
              {planFeatures.map((f) => (
                <li key={f}>{f}</li>
              ))}
              <li>Einmalige Zahlung, keine automatische Verlängerung</li>
            </ul>

            <h2>Für wen sich {product.name} lohnen</h2>
            <ul>
              {page.forWhom.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ul>

            <h2>Preisvergleich aller Laufzeiten</h2>
            <div className="table-wrap">
              <table className="compare">
                <thead>
                  <tr>
                    <th scope="col">Paket</th>
                    <th scope="col">Preis</th>
                    <th scope="col">Pro Monat</th>
                  </tr>
                </thead>
                <tbody>
                  {[...plans].reverse().map((p) => (
                    <tr key={p.id} className={p.id === product.id ? "is-current" : undefined}>
                      <th scope="row">
                        {p.id === product.id || !p.page ? `IPTV ${p.name}` : <Link href={p.page}>IPTV {p.name}</Link>}
                      </th>
                      <td>{formatEuro(p.price)}</td>
                      <td>{formatEuro(monthly(p))}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {save > 0 && (
              <p>
                Im Vergleich zum {plans[0].months}-Monats-Paket sparst du mit {product.name} {save} % pro Monat.
              </p>
            )}

            <h2>So bestellst du</h2>
            <ol>
              <li>Klick auf „{product.name} bestellen“ und wähle dein Gerät.</li>
              <li>Wähle Krypto, Kredit- oder Debitkarte oder PayPal.</li>
              <li>Nach der Zahlung bekommst du Zugangsdaten und die Anleitung für dein Gerät.</li>
            </ol>

            <h2>Fragen zu diesem Paket</h2>
            <FaqList items={page.faqs} />
          </article>

          <aside className="box">
            <h2 style={{ fontSize: "var(--step-1)" }}>IPTV {product.name}</h2>
            <p className="plan-price" style={{ textAlign: "left", fontSize: "var(--step-3)", margin: "0 0 0.25rem" }}>
              {price}
            </p>
            <p className="muted" style={{ marginBottom: "1rem" }}>
              {perMonth} pro Monat, einmalig
            </p>
            <OrderButton productId={product.id} className="btn btn-primary">
              {product.name} bestellen
            </OrderButton>
            <p className="meta-line" style={{ marginTop: "0.75rem" }}>
              Erst testen? <Link href="/iptv-testen">24 Stunden für {formatEuro(trial.price)}</Link>
            </p>
          </aside>
        </div>
      </div>
      <CtaBand />
      <JsonLd
        data={[
          singleProductSchema(product, `IPTV-Abo ${product.name}`, page.description(price, perMonth)),
          faqSchema(page.faqs),
        ]}
      />
    </>
  );
}
