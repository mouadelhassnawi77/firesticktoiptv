import type { Metadata } from "next";
import Link from "next/link";
import Breadcrumbs from "@/components/Breadcrumbs";
import Pricing from "@/components/Pricing";
import FaqList from "@/components/FaqList";
import CtaBand from "@/components/CtaBand";
import JsonLd from "@/components/JsonLd";
import { faqs } from "@/lib/faqs";
import { formatEuro } from "@/lib/site";
import { lowestMonthly, trial, plans, monthly } from "@/lib/shop";
import { pageMetadata, productSchema } from "@/lib/seo";

export const metadata: Metadata = pageMetadata({
  title: `IPTV Preise: Abo ab ${formatEuro(lowestMonthly)} im Monat, Test ${formatEuro(trial.price)}`,
  description: `IPTV-Abo kaufen: ${plans.map((p) => `${p.name} ${formatEuro(p.price)}`).join(", ")}. 24-Stunden-Test für ${formatEuro(trial.price)}. Zahlung per Krypto, Karte oder PayPal, keine automatische Verlängerung.`,
  path: "/preise",
});

const priceFaqs = faqs.filter((f) =>
  [
    "Wie bezahle ich?",
    "Verlängert sich das Abo automatisch?",
    "Kann ich das Abo auf mehreren Geräten nutzen?",
    "Wie schnell kann ich nach der Bestellung schauen?",
  ].includes(f.q)
);

export default function PricingPage() {
  return (
    <>
      <div className="wrap page-head">
        <Breadcrumbs items={[{ name: "Preise", path: "/preise" }]} />
        <h1>IPTV Preise und Pakete</h1>
        <p className="lead">
          Du zahlst einmal für den gewählten Zeitraum, danach endet das Abo automatisch. Unsicher? Starte mit dem{" "}
          <Link href="/iptv-testen">24-Stunden-Test für {formatEuro(trial.price)}</Link>.
        </p>
      </div>
      <section className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }} aria-label="Pakete">
        <Pricing />
      </section>

      <section className="section" aria-labelledby="vergleich">
        <div className="wrap">
          <div className="section-intro">
            <h2 id="vergleich">Alle Pakete im Vergleich</h2>
            <p>Der Umfang ist bei jedem Paket gleich. Unterschiedlich sind nur Laufzeit und Monatspreis.</p>
          </div>
          <div className="table-wrap" style={{ maxWidth: "46rem" }}>
            <table className="compare">
              <thead>
                <tr>
                  <th scope="col">Paket</th>
                  <th scope="col">Preis</th>
                  <th scope="col">Pro Monat</th>
                </tr>
              </thead>
              <tbody>
                {[...plans].reverse().map((p) => (
                  <tr key={p.id} className={p.popular ? "is-current" : undefined}>
                    <th scope="row">
                      {p.page ? <Link href={p.page}>IPTV {p.name}</Link> : p.name}
                      {p.popular ? " (beliebteste Wahl)" : ""}
                    </th>
                    <td>{formatEuro(p.price)}</td>
                    <td>{formatEuro(monthly(p))}</td>
                  </tr>
                ))}
                <tr>
                  <th scope="row">
                    <Link href="/iptv-testen">24-Stunden-Test</Link>
                  </th>
                  <td>{formatEuro(trial.price)}</td>
                  <td>einmalig</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="wrap split">
          <div>
            <h2>Fragen zu Bestellung und Zahlung</h2>
            <p className="muted">
              Alle weiteren Antworten auf der <Link href="/faq">FAQ-Seite</Link>.
            </p>
          </div>
          <FaqList items={priceFaqs} />
        </div>
      </section>
      <CtaBand />
      <JsonLd data={productSchema()} />
    </>
  );
}
