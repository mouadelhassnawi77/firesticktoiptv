import type { Metadata } from "next";
import LegalPage from "@/components/LegalPage";
import { site } from "@/lib/site";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata({
  title: "AGB und Widerrufsbelehrung",
  description: `Allgemeine Geschäftsbedingungen und Widerrufsbelehrung von ${site.name}.`,
  path: "/agb",
  noindex: true,
});

export default function AgbPage() {
  return (
    <LegalPage title="AGB und Widerrufsbelehrung" path="/agb">
      <h2>1. Geltungsbereich</h2>
      <p>
        Diese Bedingungen gelten für alle Verträge zwischen {site.legalName} und Kundinnen und Kunden über die
        Nutzung unseres IPTV-Dienstes.
      </p>
      <h2>2. Vertragsschluss</h2>
      <p>
        Die Darstellung der Pakete auf dieser Website ist kein verbindliches Angebot. Bei Zahlung per Krypto gibst du
        mit dem Klick auf „Zahlungspflichtig bestellen“ ein verbindliches Angebot ab. Bei Zahlung per Kredit- oder
        Debitkarte oder PayPal sendest du deine Bestellung per WhatsApp. Der Vertrag kommt jeweils zustande, wenn wir
        die Bestellung bestätigen oder die Zugangsdaten zusenden.
      </p>
      <h2>3. Laufzeit</h2>
      <p>
        Der Vertrag läuft für den gebuchten Zeitraum und endet automatisch. Es gibt keine stillschweigende
        Verlängerung.
      </p>
      <h2>4. Preise und Zahlung</h2>
      <p>
        Alle Preise sind Endpreise inklusive gesetzlicher Mehrwertsteuer und werden einmalig gezahlt. Möglich sind
        Krypto (Bitcoin, USDT), Kredit- oder Debitkarte und PayPal. Bei Krypto gilt der auf der Bezahlseite angezeigte
        Betrag, der zum Zeitpunkt der Bestellung aus dem Euro-Preis berechnet wird.
      </p>
      <h2>5. Widerrufsrecht</h2>
      <p>
        Verbraucher haben ein vierzehntägiges Widerrufsrecht. Hier gehört die vollständige Widerrufsbelehrung mit
        Muster-Widerrufsformular hin.
      </p>
    </LegalPage>
  );
}
