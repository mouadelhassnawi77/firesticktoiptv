import type { Metadata } from "next";
import LegalPage from "@/components/LegalPage";
import { site } from "@/lib/site";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata({
  title: "Datenschutzerklärung",
  description: `Datenschutzerklärung von ${site.name}: welche Daten wir verarbeiten und welche Rechte du hast.`,
  path: "/datenschutz",
  noindex: true,
});

export default function DatenschutzPage() {
  const a = site.address;
  return (
    <LegalPage title="Datenschutzerklärung" path="/datenschutz">
      <h2>Verantwortlicher</h2>
      <p>
        {site.legalName}, {a.street}, {a.zip} {a.city}. E-Mail: <a href={`mailto:${site.email}`}>{site.email}</a>
      </p>

      <h2>Hosting, Datenbank und Server-Logfiles</h2>
      <p>
        Beim Aufruf dieser Website verarbeitet unser Hosting-Anbieter technisch notwendige Daten (IP-Adresse, Datum
        und Uhrzeit, aufgerufene Seite, Browser). Rechtsgrundlage ist Art. 6 Abs. 1 lit. f DSGVO, unser berechtigtes
        Interesse an einem sicheren und stabilen Betrieb. Die Logfiles werden nach kurzer Zeit gelöscht. Die Website
        wird bei Vercel Inc. gehostet, Bestelldaten liegen in einer Datenbank bei Neon Inc. (Rechenzentrum in der EU).
        Mit beiden Anbietern besteht ein Vertrag zur Auftragsverarbeitung.
      </p>

      {process.env.NEXT_PUBLIC_GA_ID ? (
        <>
          <h2>Cookies und Webanalyse mit Google Analytics</h2>
          <p>
            Nur wenn du im Cookie-Hinweis auf „Akzeptieren“ klickst, nutzen wir Google Analytics 4 der Google Ireland
            Limited, Gordon House, Barrow Street, Dublin 4, Irland. Google Analytics setzt Cookies (z. B. „_ga“) und
            verarbeitet Nutzungsdaten wie aufgerufene Seiten, Verweildauer, Gerät, Browser und ungefähren Standort. Die
            IP-Adresse wird von Google Analytics 4 nicht gespeichert. Daten können an Google LLC in die USA übertragen
            werden; Google ist nach dem EU-US Data Privacy Framework zertifiziert. Rechtsgrundlage ist deine Einwilligung
            (Art. 6 Abs. 1 lit. a DSGVO, § 25 Abs. 1 TDDDG). Die Daten werden nach 14 Monaten gelöscht.
          </p>
          <p>
            Du kannst deine Einwilligung jederzeit über „Cookie-Einstellungen“ im Seitenfuß widerrufen. Ohne
            Einwilligung wird Google Analytics nicht geladen. Deine Auswahl speichern wir im Speicher deines Browsers.
            Schriftarten werden lokal von unserem Server geladen, es findet keine Verbindung zu Google Fonts statt.
          </p>
        </>
      ) : (
        <>
          <h2>Keine Cookies, kein Tracking</h2>
          <p>
            Diese Website setzt keine Cookies und nutzt keine Analyse- oder Werbedienste. Schriftarten werden lokal von
            unserem Server geladen, es findet keine Verbindung zu Google Fonts statt.
          </p>
        </>
      )}

      <h2>Bestellformular</h2>
      <p>
        Die Angaben im Bestellformular (Name, E-Mail, WhatsApp-Nummer, Gerät, Zahlungsart, gewähltes Paket)
        speichern wir in unserer Bestelldatenbank, um deine Bestellung abzuwickeln, dein Abo freizuschalten und dich
        vor dem Ablauf zu erinnern. Bei Zahlung per Krypto speichern wir zusätzlich Betrag und Transaktions-ID, wenn du
        sie angibst. Zusätzlich werden die Angaben in eine WhatsApp-Nachricht übernommen, die du selbst absendest.
        Rechtsgrundlage ist Art. 6 Abs. 1 lit. b DSGVO (Vertragsabwicklung). Wir löschen die Daten, sobald sie dafür
        nicht mehr erforderlich sind und keine gesetzlichen Aufbewahrungspflichten (z. B. steuerliche) bestehen.
      </p>

      <h2>Krypto-Kurse (CoinGecko)</h2>
      <p>
        Auf der Bezahlseite für Krypto rufen wir den aktuellen Kurs bei CoinGecko ab. Dabei wird deine IP-Adresse an
        CoinGecko übertragen. Es werden keine Bestelldaten übermittelt. Rechtsgrundlage ist Art. 6 Abs. 1 lit. b DSGVO.
      </p>

      <h2>Kontakt per WhatsApp und E-Mail</h2>
      <p>
        Wenn du uns per WhatsApp oder E-Mail schreibst, verarbeiten wir deine Angaben zur Bearbeitung deiner Anfrage
        und zur Vertragsabwicklung (Art. 6 Abs. 1 lit. b DSGVO). WhatsApp wird von der WhatsApp Ireland Ltd.
        betrieben; dabei können Daten in die USA übermittelt werden. Wenn du das nicht möchtest, schreib uns per
        E-Mail.
      </p>

      <h2>Deine Rechte</h2>
      <p>
        Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit
        und Widerspruch (Art. 15 bis 21 DSGVO). Außerdem kannst du dich bei einer Datenschutz-Aufsichtsbehörde
        beschweren.
      </p>
    </LegalPage>
  );
}
