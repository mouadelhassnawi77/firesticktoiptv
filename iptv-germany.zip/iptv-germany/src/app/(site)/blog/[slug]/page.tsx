import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Breadcrumbs from "@/components/Breadcrumbs";
import CtaBand from "@/components/CtaBand";
import JsonLd from "@/components/JsonLd";
import { posts, getPost, formatDate } from "@/lib/posts";
import { pageMetadata, articleSchema } from "@/lib/seo";

type Props = { params: Promise<{ slug: string }> };

export const dynamicParams = false;
export function generateStaticParams() {
  return posts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) return {};
  return pageMetadata({
    title: post.metaTitle,
    description: post.description,
    path: `/blog/${post.slug}`,
    type: "article",
    publishedTime: post.published,
    modifiedTime: post.modified,
  });
}

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/ä/g, "ae")
    .replace(/ö/g, "oe")
    .replace(/ü/g, "ue")
    .replace(/ß/g, "ss")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

export default async function PostPage({ params }: Props) {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) notFound();
  const path = `/blog/${post.slug}`;

  return (
    <>
      <div className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
        <div className="page-head" style={{ paddingInline: 0 }}>
          <Breadcrumbs
            items={[
              { name: "Ratgeber", path: "/blog" },
              { name: post.title, path },
            ]}
          />
          <h1>{post.title}</h1>
          <p className="lead">{post.description}</p>
          <p className="meta-line">
            Veröffentlicht am <time dateTime={post.published}>{formatDate(post.published)}</time>
            {post.modified !== post.published && (
              <>
                , aktualisiert am <time dateTime={post.modified}>{formatDate(post.modified)}</time>
              </>
            )}
            , {post.readingMinutes} Minuten Lesezeit
          </p>
        </div>

        <div className="two-col">
          <article className="prose">
            {post.sections.map((s) => (
              <section key={s.heading} aria-labelledby={slugify(s.heading)}>
                <h2 id={slugify(s.heading)}>{s.heading}</h2>
                {s.paragraphs.map((p) => (
                  <p key={p.slice(0, 40)}>{p}</p>
                ))}
                {s.list && (
                  <ul>
                    {s.list.map((li) => (
                      <li key={li}>{li}</li>
                    ))}
                  </ul>
                )}
              </section>
            ))}
          </article>

          <aside>
            <nav className="box" aria-label="Inhalt dieses Artikels" style={{ marginBottom: "1.5rem" }}>
              <h2 style={{ fontSize: "var(--step-1)" }}>Inhalt</h2>
              <ul className="link-list">
                {post.sections.map((s) => (
                  <li key={s.heading}>
                    <a href={`#${slugify(s.heading)}`}>{s.heading}</a>
                  </li>
                ))}
              </ul>
            </nav>
            <div className="box">
              <h2 style={{ fontSize: "var(--step-1)" }}>Weiterlesen</h2>
              <ul className="link-list">
                {post.related.map((r) => (
                  <li key={r.href}>
                    <Link href={r.href}>{r.label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </div>
      <CtaBand />
      <JsonLd
        data={articleSchema({
          title: post.title,
          description: post.description,
          path,
          published: post.published,
          modified: post.modified,
        })}
      />
    </>
  );
}
