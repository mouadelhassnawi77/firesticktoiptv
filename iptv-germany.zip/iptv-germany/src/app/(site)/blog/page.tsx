import type { Metadata } from "next";
import Link from "next/link";
import Breadcrumbs from "@/components/Breadcrumbs";
import CtaBand from "@/components/CtaBand";
import { posts, formatDate } from "@/lib/posts";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata({
  title: "IPTV Ratgeber: Tipps, Technik und Einrichtung",
  description:
    "Der IPTV-Ratgeber: was IPTV ist, welche Internetgeschwindigkeit du brauchst, M3U oder Xtream Codes und wie du Ruckler vermeidest.",
  path: "/blog",
});

export default function BlogIndex() {
  const sorted = [...posts].sort((a, b) => b.published.localeCompare(a.published));
  return (
    <>
      <div className="wrap page-head">
        <Breadcrumbs items={[{ name: "Ratgeber", path: "/blog" }]} />
        <h1>IPTV Ratgeber</h1>
        <p className="lead">Verständliche Antworten rund um IPTV, Geräte und Internetverbindung.</p>
      </div>
      <section className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
        <ul className="post-list">
          {sorted.map((p) => (
            <li key={p.slug}>
              <h2>
                <Link href={`/blog/${p.slug}`}>{p.title}</Link>
              </h2>
              <p className="muted">{p.description}</p>
              <p className="meta-line">
                <time dateTime={p.published}>{formatDate(p.published)}</time>, {p.readingMinutes} Minuten Lesezeit
              </p>
            </li>
          ))}
        </ul>
      </section>
      <CtaBand />
    </>
  );
}
