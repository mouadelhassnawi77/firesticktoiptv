import type { Metadata } from "next";
import Link from "next/link";
import Breadcrumbs from "@/components/Breadcrumbs";
import { site, whatsappLink } from "@/lib/site";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata({
  title: "Kontakt und Support per WhatsApp",
  description: `Fragen zu IPTV, Bestellung oder Einrichtung? Schreib uns per WhatsApp oder E-Mail. Support ${site.supportHours.toLowerCase()}.`,
  path: "/kontakt",
});

export default function ContactPage() {
  return (
    <div className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
      <div className="page-head" style={{ paddingInline: 0 }}>
        <Breadcrumbs items={[{ name: "Kontakt", path: "/kontakt" }]} />
        <h1>Kontakt und Support</h1>
        <p className="lead">
          Am schnellsten erreichst du uns per WhatsApp. {site.supportHours}, auf Deutsch.
        </p>
      </div>
      <div className="two-col">
        <div className="prose">
          <h2>WhatsApp</h2>
          <p>Für Testzugang, Bestellung und Hilfe bei der Einrichtung. Schick gern ein Foto vom Bildschirm mit.</p>
          <p>
            <a className="btn btn-primary" href={whatsappLink(`Hallo ${site.supportName}, ich habe eine Frage zu IPTV.`)} rel="nofollow noopener" target="_blank">
              Chat auf WhatsApp öffnen
            </a>
          </p>
          <h2>E-Mail</h2>
          <p>
            Für Rechnungen und alles, was nicht eilt: <a href={`mailto:${site.email}`}>{site.email}</a>
          </p>
        </div>
        <aside className="box">
          <h2 style={{ fontSize: "var(--step-1)" }}>Vielleicht schon beantwortet</h2>
          <ul className="link-list">
            <li><Link href="/faq">Häufige Fragen</Link></li>
            <li><Link href="/anleitung">Anleitungen für alle Geräte</Link></li>
            <li><Link href="/blog/internetgeschwindigkeit-iptv">Hilfe bei Rucklern</Link></li>
          </ul>
        </aside>
      </div>
    </div>
  );
}
