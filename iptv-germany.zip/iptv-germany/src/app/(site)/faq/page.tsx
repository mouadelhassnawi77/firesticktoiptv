import type { Metadata } from "next";
import Breadcrumbs from "@/components/Breadcrumbs";
import FaqList from "@/components/FaqList";
import CtaBand from "@/components/CtaBand";
import JsonLd from "@/components/JsonLd";
import { faqs } from "@/lib/faqs";
import { pageMetadata, faqSchema } from "@/lib/seo";

export const metadata: Metadata = pageMetadata({
  title: "IPTV FAQ: Antworten auf die häufigsten Fragen",
  description:
    "Antworten zu IPTV: Testzugang, Geräte, Internetgeschwindigkeit, Laufzeit, Zahlung und Hilfe bei Rucklern. Alles Wichtige auf einer Seite.",
  path: "/faq",
});

// Das FAQPage-Schema steht nur hier, nicht zusätzlich auf der Startseite (keine doppelten Markups).
export default function FaqPage() {
  return (
    <>
      <div className="wrap page-head">
        <Breadcrumbs items={[{ name: "FAQ", path: "/faq" }]} />
        <h1>Häufige Fragen zu IPTV</h1>
        <p className="lead">Deine Frage ist nicht dabei? Schreib uns per WhatsApp, wir antworten auf Deutsch.</p>
      </div>
      <section className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)", maxWidth: "860px", marginInline: "auto" }}>
        <FaqList items={faqs} />
      </section>
      <CtaBand />
      <JsonLd data={faqSchema(faqs)} />
    </>
  );
}
