import type { Metadata } from "next";
import Link from "next/link";
import Breadcrumbs from "@/components/Breadcrumbs";
import JsonLd from "@/components/JsonLd";
import OrderButton from "@/components/order/OrderButton";
import { formatEuro } from "@/lib/site";
import { devices, trial, popularPlan } from "@/lib/shop";
import { pageMetadata, singleProductSchema } from "@/lib/seo";

const title = `IPTV testen: ${trial.hours} Stunden für ${formatEuro(trial.price)}`;
const description = `IPTV ${trial.hours} Stunden testen für ${formatEuro(trial.price)}: voller Zugang zu allen Sendern und der Mediathek auf deinem Gerät. Endet automatisch, kein Abo.`;

export const metadata: Metadata = pageMetadata({ title, description, path: "/iptv-testen" });

export default function TrialPage() {
  return (
    <div className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
      <div className="page-head" style={{ paddingInline: 0 }}>
        <Breadcrumbs items={[{ name: "IPTV testen", path: "/iptv-testen" }]} />
        <h1>
          IPTV {trial.hours} Stunden testen für {formatEuro(trial.price)}
        </h1>
        <p className="lead">
          Ein Tag voller Zugang mit allen Sendern, TV-Guide und Mediathek. Der Test endet automatisch, es entsteht kein
          Abo.
        </p>
      </div>

      <div className="two-col">
        <section aria-labelledby="geraet-waehlen">
          <h2 id="geraet-waehlen" style={{ fontSize: "var(--step-2)" }}>
            Auf welchem Gerät möchtest du testen?
          </h2>
          <ul className="trial-devices">
            {devices.map((d) => (
              <li key={d.id}>
                <OrderButton productId={trial.id} device={d.id} className="btn">
                  {d.label}
                  <span aria-hidden="true">{formatEuro(trial.price)}</span>
                </OrderButton>
              </li>
            ))}
          </ul>

          <div className="prose" style={{ marginTop: "2.5rem" }}>
            <h2>So läuft der Test ab</h2>
            <ol>
              <li>Gerät wählen, Name und E-Mail eintragen, Zahlungsart wählen.</li>
              <li>Mit Krypto zahlst du direkt. Mit Karte oder PayPal schicken wir dir den Zahlungslink per WhatsApp.</li>
              <li>Du bekommst Zugangsdaten und die Anleitung für dein Gerät.</li>
              <li>
                Nach {trial.hours} Stunden endet der Zugang automatisch. Gefällt es dir, wählst du ein{" "}
                <Link href="/preise">Paket</Link>, am günstigsten ist das{" "}
                <Link href={popularPlan.page ?? "/preise"}>Jahresabo</Link>.
              </li>
            </ol>
          </div>
        </section>

        <aside className="box">
          <h2 style={{ fontSize: "var(--step-1)" }}>Vor dem Test</h2>
          <ul>
            <li>Mindestens 16 Mbit/s für HD, 25 Mbit/s für 4K</li>
            <li>Gerät am besten per LAN-Kabel verbinden</li>
            <li>
              Anleitung schon mal ansehen: <Link href="/anleitung">alle Geräte</Link>
            </li>
          </ul>
        </aside>
      </div>
      <JsonLd data={singleProductSchema(trial, `IPTV ${trial.hours}-Stunden-Test`, description)} />
    </div>
  );
}
