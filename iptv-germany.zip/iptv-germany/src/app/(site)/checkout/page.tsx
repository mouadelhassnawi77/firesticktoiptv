import type { Metadata } from "next";
import CheckoutClient from "@/components/order/CheckoutClient";

// Checkout gehört nicht in den Index und nicht in die Sitemap
export const metadata: Metadata = {
  title: "Bezahlen mit Krypto",
  robots: { index: false, follow: false },
};

export default function CheckoutPage() {
  return (
    <div className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
      <div className="page-head" style={{ paddingInline: 0 }}>
        <h1>Bezahlen mit Krypto</h1>
        <p className="lead">Prüfe deine Bestellung, bestelle zahlungspflichtig und sende den angezeigten Betrag.</p>
      </div>
      <CheckoutClient />
    </div>
  );
}
