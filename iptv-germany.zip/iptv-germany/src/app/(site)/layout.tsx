import "./consent.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import JsonLd from "@/components/JsonLd";
import OrderProvider from "@/components/order/OrderProvider";
import Analytics from "@/components/Analytics";
import { organizationSchema, websiteSchema } from "@/lib/seo";

/** Öffentliche Seiten: Kopf, Fuß, Bestell-Popup und Organisations-Schema. Der Admin-Bereich hat ein eigenes Layout. */
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <a href="#inhalt" className="skip-link">
        Zum Inhalt springen
      </a>
      <OrderProvider>
        <Header />
        <main id="inhalt">{children}</main>
        <Footer />
      </OrderProvider>
      <JsonLd data={[organizationSchema(), websiteSchema()]} />
      <Analytics />
    </>
  );
}
