import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Breadcrumbs from "@/components/Breadcrumbs";
import DeviceList from "@/components/DeviceList";
import JsonLd from "@/components/JsonLd";
import { guides, getGuide } from "@/lib/guides";
import { formatDate } from "@/lib/posts";
import OrderButton from "@/components/order/OrderButton";
import { formatEuro } from "@/lib/site";
import { trial } from "@/lib/shop";
import { pageMetadata, howToSchema } from "@/lib/seo";

type Props = { params: Promise<{ geraet: string }> };

// Alle Anleitungen werden beim Build statisch erzeugt; unbekannte Slugs geben 404.
export const dynamicParams = false;
export function generateStaticParams() {
  return guides.map((g) => ({ geraet: g.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { geraet } = await params;
  const guide = getGuide(geraet);
  if (!guide) return {};
  return pageMetadata({
    title: guide.metaTitle,
    description: guide.description,
    path: `/anleitung/${guide.slug}`,
    type: "article",
    modifiedTime: guide.updated,
  });
}

export default async function GuidePage({ params }: Props) {
  const { geraet } = await params;
  const guide = getGuide(geraet);
  if (!guide) notFound();

  const path = `/anleitung/${guide.slug}`;

  return (
    <div className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
      <div className="page-head" style={{ paddingInline: 0 }}>
        <Breadcrumbs
          items={[
            { name: "Anleitungen", path: "/anleitung" },
            { name: guide.device, path },
          ]}
        />
        <h1>{guide.title}</h1>
        <p className="lead">{guide.intro}</p>
        <p className="meta-line">
          Aktualisiert am <time dateTime={guide.updated}>{formatDate(guide.updated)}</time>
        </p>
      </div>

      <div className="two-col">
        <article className="prose">
          <h2>Das brauchst du</h2>
          <ul>
            {guide.needs.map((n) => (
              <li key={n}>{n}</li>
            ))}
          </ul>

          <h2>Schritt für Schritt</h2>
          <ol className="steps" style={{ marginBottom: "2rem" }}>
            {guide.steps.map((s) => (
              <li key={s.title}>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
              </li>
            ))}
          </ol>

          <h2>Tipps für ein ruckelfreies Bild</h2>
          <ul>
            {guide.tips.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
          <p>
            Noch mehr dazu im Ratgeber:{" "}
            <Link href="/blog/internetgeschwindigkeit-iptv">Welche Internetgeschwindigkeit brauche ich für IPTV?</Link>
          </p>
        </article>

        <aside className="box">
          <h2 style={{ fontSize: "var(--step-1)" }}>Noch keine Zugangsdaten?</h2>
          <p>
            Teste {trial.hours} Stunden auf deinem {guide.device} für {formatEuro(trial.price)}.
          </p>
          <OrderButton productId={trial.id} device={guide.slug} className="btn btn-primary">
            Test für {formatEuro(trial.price)} bestellen
          </OrderButton>
          <p className="meta-line" style={{ marginTop: "0.75rem" }}>
            Oder direkt ein Abo wählen: <Link href="/preise">Preise</Link>
          </p>
        </aside>
      </div>

      <section style={{ marginTop: "clamp(3rem, 7vw, 5rem)" }} aria-labelledby="andere-geraete">
        <h2 id="andere-geraete">Anleitungen für andere Geräte</h2>
        <DeviceList exclude={guide.slug} />
      </section>

      <JsonLd
        data={howToSchema({
          title: guide.title,
          description: guide.description,
          path,
          steps: guide.steps.map((s) => ({ title: s.title, text: s.text })),
        })}
      />
    </div>
  );
}
