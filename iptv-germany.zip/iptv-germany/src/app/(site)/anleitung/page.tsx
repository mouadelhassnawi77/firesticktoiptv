import type { Metadata } from "next";
import Breadcrumbs from "@/components/Breadcrumbs";
import DeviceList from "@/components/DeviceList";
import CtaBand from "@/components/CtaBand";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata({
  title: "IPTV einrichten: Anleitungen für alle Geräte",
  description:
    "IPTV Schritt für Schritt einrichten: Anleitungen für Fire TV Stick, Samsung und LG Smart TV, Android, iPhone, MAG-Box sowie Windows und Mac.",
  path: "/anleitung",
});

export default function GuidesPage() {
  return (
    <>
      <div className="wrap page-head">
        <Breadcrumbs items={[{ name: "Anleitungen", path: "/anleitung" }]} />
        <h1>IPTV einrichten: Anleitungen für alle Geräte</h1>
        <p className="lead">
          Wähle dein Gerät. Jede Anleitung führt dich in wenigen Schritten von der App-Installation bis zum ersten
          Sender.
        </p>
      </div>
      <section className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
        <DeviceList />
      </section>
      <CtaBand title="Hängst du bei einem Schritt?" text="Schick uns ein Foto vom Bildschirm per WhatsApp. Wir helfen dir weiter." />
    </>
  );
}
