import type { Metadata } from "next";
import LegalPage from "@/components/LegalPage";
import { site } from "@/lib/site";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata({
  title: "Impressum",
  description: `Impressum und Anbieterkennzeichnung von ${site.name}.`,
  path: "/impressum",
  noindex: true,
});

export default function ImpressumPage() {
  const a = site.address;
  return (
    <LegalPage title="Impressum" path="/impressum">
      <h2>Angaben gemäß § 5 DDG</h2>
      <p>
        {site.legalName}
        <br />
        {a.street}
        <br />
        {a.zip} {a.city}
        <br />
        Deutschland
      </p>
      <h2>Vertreten durch</h2>
      <p>{site.managingDirector}</p>
      <h2>Kontakt</h2>
      <p>
        E-Mail: <a href={`mailto:${site.email}`}>{site.email}</a>
        <br />
        WhatsApp: +{site.whatsapp}
      </p>
      <h2>Registereintrag</h2>
      <p>{site.register}</p>
      <h2>Umsatzsteuer-ID</h2>
      <p>Umsatzsteuer-Identifikationsnummer gemäß § 27a UStG: {site.vatId}</p>
      <h2>Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV</h2>
      <p>
        {site.managingDirector}, Anschrift wie oben
      </p>
      <h2>Verbraucherstreitbeilegung</h2>
      <p>
        Wir sind nicht bereit und nicht verpflichtet, an Streitbeilegungsverfahren vor einer
        Verbraucherschlichtungsstelle teilzunehmen.
      </p>
    </LegalPage>
  );
}
