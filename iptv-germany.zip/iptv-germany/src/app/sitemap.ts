import type { MetadataRoute } from "next";
import { guides } from "@/lib/guides";
import { posts } from "@/lib/posts";
import { absoluteUrl } from "@/lib/site";
import { planPages } from "@/lib/planPages";

// Nur indexierbare Seiten. Rechtstexte (noindex) sind bewusst nicht enthalten.
export default function sitemap(): MetadataRoute.Sitemap {
  const latestPost = posts.map((p) => p.modified).sort().at(-1);
  const latestGuide = guides.map((g) => g.updated).sort().at(-1);

  const staticPages: MetadataRoute.Sitemap = [
    { url: absoluteUrl("/"), lastModified: latestPost, changeFrequency: "weekly", priority: 1 },
    { url: absoluteUrl("/preise"), changeFrequency: "monthly", priority: 0.9 },
    { url: absoluteUrl("/iptv-testen"), changeFrequency: "monthly", priority: 0.9 },
    { url: absoluteUrl("/anleitung"), lastModified: latestGuide, changeFrequency: "monthly", priority: 0.8 },
    { url: absoluteUrl("/blog"), lastModified: latestPost, changeFrequency: "weekly", priority: 0.7 },
    { url: absoluteUrl("/faq"), changeFrequency: "monthly", priority: 0.7 },
    { url: absoluteUrl("/kontakt"), changeFrequency: "yearly", priority: 0.4 },
  ];

  return [
    ...staticPages,
    ...planPages.map((p) => ({
      url: absoluteUrl(`/preise/${p.slug}`),
      changeFrequency: "monthly" as const,
      priority: p.planId === "12-monate" ? 0.9 : 0.8,
    })),
    ...guides.map((g) => ({
      url: absoluteUrl(`/anleitung/${g.slug}`),
      lastModified: g.updated,
      changeFrequency: "monthly" as const,
      priority: 0.8,
    })),
    ...posts.map((p) => ({
      url: absoluteUrl(`/blog/${p.slug}`),
      lastModified: p.modified,
      changeFrequency: "monthly" as const,
      priority: 0.6,
    })),
  ];
}
