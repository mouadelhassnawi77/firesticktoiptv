"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { formatEuro } from "@/lib/site";
import { trial } from "@/lib/shop";

type Item = { href: string; label: string };

/** Einzige Client-Komponente: schließt sich bei Seitenwechsel automatisch. */
export default function MobileNav({ items }: { items: Item[] }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => setOpen(false), [pathname]);

  return (
    <>
      <button
        type="button"
        className="menu-toggle"
        aria-expanded={open}
        aria-controls="mobile-menu"
        onClick={() => setOpen((v) => !v)}
      >
        {open ? "Schließen" : "Menü"}
      </button>
      <nav
        id="mobile-menu"
        className="nav-mobile"
        aria-label="Hauptnavigation mobil"
        hidden={!open}
        style={{ position: "absolute", left: 0, right: 0, top: "100%" }}
      >
        <ul>
          {items.map((item) => (
            <li key={item.href}>
              <Link href={item.href} aria-current={pathname === item.href ? "page" : undefined}>
                {item.label}
              </Link>
            </li>
          ))}
          <li style={{ border: 0 }}>
            <Link href="/iptv-testen" className="btn btn-primary">
              {trial.hours} Stunden testen für {formatEuro(trial.price)}
            </Link>
          </li>
        </ul>
      </nav>
    </>
  );
}
