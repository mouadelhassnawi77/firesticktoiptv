import Link from "next/link";
import { LogoMark } from "./Logo";
import { guides } from "@/lib/guides";
import { posts } from "@/lib/posts";
import { site, formatEuro } from "@/lib/site";
import { trial, popularPlan } from "@/lib/shop";
import ConsentLink from "./ConsentLink";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <Link href="/" className="brand" style={{ marginBottom: "0.75rem" }}>
              <LogoMark size={22} />
              {site.name}
            </Link>
            <p className="muted" style={{ fontSize: "0.9375rem" }}>
              IPTV für Deutschland. Support {site.supportHours.toLowerCase()}.
            </p>
          </div>
          <div>
            <h2>Angebot</h2>
            <ul>
              <li><Link href="/preise">Preise</Link></li>
              {popularPlan.page && <li><Link href={popularPlan.page}>IPTV-Jahresabo</Link></li>}
              <li><Link href="/iptv-testen">24-Stunden-Test für {formatEuro(trial.price)}</Link></li>
              <li><Link href="/faq">Häufige Fragen</Link></li>
              <li><Link href="/kontakt">Kontakt</Link></li>
            </ul>
          </div>
          <div>
            <h2>Anleitungen</h2>
            <ul>
              {guides.map((g) => (
                <li key={g.slug}>
                  <Link href={`/anleitung/${g.slug}`}>{g.device}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2>Ratgeber</h2>
            <ul>
              {posts.map((p) => (
                <li key={p.slug}>
                  <Link href={`/blog/${p.slug}`}>{p.title}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2>Rechtliches</h2>
            <ul>
              <li><Link href="/impressum">Impressum</Link></li>
              <li><Link href="/datenschutz">Datenschutz</Link></li>
              <li><Link href="/agb">AGB</Link></li>
              {process.env.NEXT_PUBLIC_GA_ID && <li><ConsentLink /></li>}
            </ul>
          </div>
        </div>
        <p className="footer-bottom">
          © {year} {site.legalName}. Alle Preise inkl. MwSt.
        </p>
      </div>
    </footer>
  );
}
