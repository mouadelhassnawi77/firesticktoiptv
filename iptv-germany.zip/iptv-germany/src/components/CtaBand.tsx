import Link from "next/link";
import OrderButton from "./order/OrderButton";
import { formatEuro } from "@/lib/site";
import { trial } from "@/lib/shop";

export default function CtaBand({
  title = `Erst ${trial.hours} Stunden testen, dann entscheiden`,
  text = `Für ${formatEuro(trial.price)} bekommst du einen Tag vollen Zugang auf deinem Gerät. Passt alles, wählst du dein Paket.`,
  device,
}: {
  title?: string;
  text?: string;
  device?: string;
}) {
  return (
    <section className="cta-band">
      <div className="wrap">
        <h2>{title}</h2>
        <p>{text}</p>
        <div className="hero-actions">
          <OrderButton productId={trial.id} device={device} className="btn btn-primary">
            {trial.hours} Stunden testen für {formatEuro(trial.price)}
          </OrderButton>
          <Link href="/preise" className="btn btn-ghost">
            Pakete ansehen
          </Link>
        </div>
      </div>
    </section>
  );
}
