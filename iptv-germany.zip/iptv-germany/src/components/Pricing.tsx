import Link from "next/link";
import OrderButton from "./order/OrderButton";
import { formatEuro } from "@/lib/site";
import { plans, trial, planFeatures, popularPlan, monthly, savingsPercent } from "@/lib/shop";

/**
 * Preisbereich: das beliebteste Paket als hervorgehobene Tafel, die anderen als Programmzeilen,
 * darunter der 24-Stunden-Test. Kaufen öffnet das Bestell-Popup.
 */
export default function Pricing({ headingLevel = 2 }: { headingLevel?: 2 | 3 }) {
  const H = headingLevel === 2 ? "h2" : "h3";
  const others = plans.filter((p) => p.id !== popularPlan.id).sort((a, b) => b.months - a.months);
  const save = savingsPercent(popularPlan);

  return (
    <div className="pricing">
      <article className="plan-featured" id={popularPlan.id} aria-labelledby={`${popularPlan.id}-title`}>
        <p className="plan-badge">Beliebteste Wahl</p>
        <H id={`${popularPlan.id}-title`} className="plan-featured-name">
          IPTV {popularPlan.name}
        </H>
        <p className="plan-featured-price">
          <span className="tabular">{formatEuro(popularPlan.price)}</span>
          <small>einmalig für {popularPlan.months} Monate</small>
        </p>
        <p className="plan-featured-per">
          Nur <strong className="tabular">{formatEuro(monthly(popularPlan))}</strong> pro Monat.
          {save > 0 && <> Du sparst {save} % im Vergleich zum {plans[0].months}-Monats-Paket.</>}
        </p>
        <ul className="plan-featured-list">
          {planFeatures.map((f) => (
            <li key={f}>{f}</li>
          ))}
          <li>Keine automatische Verlängerung</li>
        </ul>
        <OrderButton productId={popularPlan.id} className="btn btn-primary btn-large">
          {popularPlan.name} bestellen
        </OrderButton>
        {popularPlan.page && (
          <Link href={popularPlan.page} className="plan-more">
            Alles zum IPTV-Jahresabo
          </Link>
        )}
      </article>

      <div className="plan-side">
        <ul className="plans">
          {others.map((p) => {
            const s = savingsPercent(p);
            return (
              <li key={p.id} id={p.id} className="plan">
                <div className="plan-name">
                  {p.page ? <Link href={p.page}>IPTV {p.name}</Link> : `IPTV ${p.name}`}
                  <small>{s > 0 ? `${s} % günstiger im Monat` : "Zum Einstieg"}</small>
                </div>
                <div className="plan-price">{formatEuro(p.price)}</div>
                <p className="plan-per">{formatEuro(monthly(p))} pro Monat</p>
                <div className="plan-cta">
                  <OrderButton productId={p.id} className="btn btn-ghost">
                    {p.name} bestellen
                  </OrderButton>
                </div>
              </li>
            );
          })}
        </ul>

        <div className="trial-row" id={trial.id}>
          <div>
            <p className="trial-title">Erst testen?</p>
            <p className="muted">
              {trial.hours} Stunden voller Zugang für <strong>{formatEuro(trial.price)}</strong>. Endet automatisch.
            </p>
          </div>
          <OrderButton productId={trial.id} className="btn btn-ghost">
            Test für {formatEuro(trial.price)} bestellen
          </OrderButton>
        </div>

        <p className="plan-footnote muted">
          Alle Preise sind Endpreise inkl. MwSt. und werden einmalig gezahlt. Zahlung per Krypto, Karte oder PayPal.
        </p>
      </div>
    </div>
  );
}
