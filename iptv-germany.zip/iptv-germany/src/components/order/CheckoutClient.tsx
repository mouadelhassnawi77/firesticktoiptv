"use client";

import Link from "next/link";
import QRCode from "qrcode";
import { useEffect, useMemo, useState } from "react";
import {
  cryptoWallets,
  deviceLabel,
  getProduct,
  ORDER_KEY,
  productLabel,
  type Order,
  type WalletId,
} from "@/lib/shop";
import { formatEuro, whatsappLink } from "@/lib/site";
import { beacon, openWhatsapp, whatsappOrderText } from "./OrderProvider";

type Status = "loading" | "missing" | "review" | "pay" | "sent";
type Rates = Partial<Record<string, number>>; // coingeckoId -> Preis in EUR

const ceilTo = (value: number, decimals: number) => {
  const f = 10 ** decimals;
  return Math.ceil(value * f) / f;
};

export default function CheckoutClient() {
  const [status, setStatus] = useState<Status>("loading");
  const [order, setOrder] = useState<Order | null>(null);
  const [walletId, setWalletId] = useState<WalletId>(
    (cryptoWallets.find((w) => w.address) ?? cryptoWallets[0]).id
  );
  const [rates, setRates] = useState<Rates | null>(null);
  const [rateError, setRateError] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const [txid, setTxid] = useState("");
  const [qr, setQr] = useState("");
  const [copied, setCopied] = useState<string | null>(null);

  // Bestellung aus dem Popup laden (liegt nur im sessionStorage dieses Tabs)
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(ORDER_KEY);
      const parsed = raw ? (JSON.parse(raw) as Order) : null;
      if (parsed && getProduct(parsed.productId)) {
        setOrder(parsed);
        setStatus("review");
      } else setStatus("missing");
    } catch {
      setStatus("missing");
    }
  }, []);

  // Live-Kurs in EUR (CoinGecko, ohne API-Key)
  useEffect(() => {
    const ids = [...new Set(cryptoWallets.map((w) => w.coingeckoId))].join(",");
    const ctrl = new AbortController();
    fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=eur`, { signal: ctrl.signal })
      .then((r) => (r.ok ? r.json() : Promise.reject(r.status)))
      .then((data: Record<string, { eur: number }>) => {
        const next: Rates = {};
        for (const [id, v] of Object.entries(data)) next[id] = v.eur;
        setRates(next);
      })
      .catch((e) => {
        if (e?.name !== "AbortError") setRateError(true);
      });
    return () => ctrl.abort();
  }, []);

  const product = order ? getProduct(order.productId) : undefined;
  const wallet = cryptoWallets.find((w) => w.id === walletId)!;
  const rate = rates?.[wallet.coingeckoId];
  const amount = product && rate ? ceilTo(product.price / rate, wallet.decimals) : null;
  const amountText = amount !== null ? `${amount.toFixed(wallet.decimals)} ${wallet.symbol}` : null;

  useEffect(() => {
    if (!wallet.address) return setQr("");
    QRCode.toString(wallet.address, {
      type: "svg",
      margin: 0,
      errorCorrectionLevel: "M",
      color: { dark: "#13233a", light: "#ffffff" },
    }).then(setQr, () => setQr(""));
  }, [wallet.address]);

  const confirmUrl = useMemo(() => {
    if (!order || !product) return "";
    const extra = wallet.address
      ? [
          "",
          `Krypto: ${amountText ?? `Gegenwert von ${formatEuro(product.price)}`} über ${wallet.network}`,
          `Gesendet an: ${wallet.address}`,
          `TXID: ${txid.trim() || "folgt"}`,
        ]
      : ["", `Ich möchte mit ${wallet.label} zahlen. Bitte schickt mir die Zahlungsdaten.`];
    return whatsappLink(whatsappOrderText(order, product, extra));
  }, [order, product, wallet, amountText, txid]);

  async function copy(text: string, key: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      /* Clipboard nicht verfügbar: Text ist markierbar */
    }
  }

  if (status === "loading") return <p className="muted">Bestellung wird geladen …</p>;

  if (status === "missing" || !order || !product) {
    return (
      <div className="box" style={{ maxWidth: "36rem" }}>
        <h2 style={{ fontSize: "var(--step-2)" }}>Keine offene Bestellung</h2>
        <p>Wähle zuerst ein Paket und „Krypto“ als Zahlungsart. Danach landest du wieder hier.</p>
        <Link href="/preise" className="btn btn-primary">
          Zu den Paketen
        </Link>
      </div>
    );
  }

  return (
    <div className="checkout-grid">
      <div>
        {status === "review" && (
          <section aria-labelledby="coin">
            <fieldset className="choices">
              <legend id="coin">Womit möchtest du bezahlen?</legend>
              <div className="choice-grid">
                {cryptoWallets.map((w) => (
                  <label key={w.id} className="choice">
                    <input
                      type="radio"
                      name="coin"
                      value={w.id}
                      checked={walletId === w.id}
                      onChange={() => setWalletId(w.id)}
                    />
                    <span>{w.label}</span>
                  </label>
                ))}
              </div>
            </fieldset>

            <label className="check-row">
              <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} />
              <span>
                Ich akzeptiere die <Link href="/agb" target="_blank">AGB</Link> und habe die{" "}
                <Link href="/agb" target="_blank">Widerrufsbelehrung</Link> und die{" "}
                <Link href="/datenschutz" target="_blank">Datenschutzerklärung</Link> gelesen.
              </span>
            </label>

            <button
              type="button"
              className="btn btn-primary order-submit"
              disabled={!accepted}
              aria-disabled={!accepted}
              style={!accepted ? { opacity: 0.55, cursor: "not-allowed" } : undefined}
              onClick={() => {
                setStatus("pay");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
            >
              Zahlungspflichtig bestellen ({formatEuro(product.price)})
            </button>
            <p className="order-foot" style={{ textAlign: "left" }}>
              Nach dem Klick siehst du die Wallet-Adresse und den genauen Betrag.
            </p>
          </section>
        )}

        {status === "pay" && (
          <section className="pay-box" aria-labelledby="pay-title">
            <h2 id="pay-title" style={{ fontSize: "var(--step-2)" }}>
              {wallet.symbol} senden
            </h2>

            {!wallet.address ? (
              <>
                <p className="warn">
                  Die Zahlung mit {wallet.label} ist gerade nicht verfügbar. Schick uns deine Bestellung per WhatsApp,
                  wir senden dir die Zahlungsdaten direkt.
                </p>
                <button type="button" className="btn btn-primary" onClick={() => { openWhatsapp(confirmUrl); setStatus("sent"); }}>
                  Bestellung per WhatsApp senden
                </button>
              </>
            ) : (
              <>
                <div className="pay-grid">
                  <div className="qr" aria-label={`QR-Code der ${wallet.label}-Adresse`} role="img" dangerouslySetInnerHTML={{ __html: qr }} />
                  <div>
                    <p className="pay-label">Betrag</p>
                    <div className="copy-field">
                      <code>{amountText ?? (rateError ? `Gegenwert von ${formatEuro(product.price)}` : "Kurs wird geladen …")}</code>
                      {amountText && (
                        <button type="button" className="btn btn-ghost btn-small" onClick={() => copy(String(amount!.toFixed(wallet.decimals)), "amount")}>
                          {copied === "amount" ? "Kopiert" : "Kopieren"}
                        </button>
                      )}
                    </div>
                    <p className="pay-label">Adresse im Netzwerk {wallet.network}</p>
                    <div className="copy-field">
                      <code>{wallet.address}</code>
                      <button type="button" className="btn btn-ghost btn-small" onClick={() => copy(wallet.address, "address")}>
                        {copied === "address" ? "Kopiert" : "Kopieren"}
                      </button>
                    </div>
                  </div>
                </div>

                <p className="warn">
                  Sende nur {wallet.symbol} über das Netzwerk <strong>{wallet.network}</strong>. Zahlungen über ein
                  anderes Netzwerk kommen nicht an. {rate && <>Kurs: 1 {wallet.symbol} = {formatEuro(rate)}.</>}
                </p>

                <div className="field" style={{ marginTop: "1.25rem" }}>
                  <label htmlFor="txid">
                    Transaktions-ID (TXID) <span className="muted">(optional, beschleunigt die Freischaltung)</span>
                  </label>
                  <input id="txid" type="text" value={txid} onChange={(e) => setTxid(e.target.value)} autoComplete="off" spellCheck={false} />
                </div>
                <button
                  type="button"
                  className="btn btn-primary order-submit"
                  onClick={() => {
                    if (order.token) {
                      beacon(`/api/orders/${order.id}/crypto`, {
                        token: order.token,
                        coin: wallet.label,
                        amount: amountText ?? `Gegenwert von ${formatEuro(product.price)}`,
                        txid,
                      });
                    }
                    openWhatsapp(confirmUrl);
                    setStatus("sent");
                  }}
                >
                  Ich habe bezahlt: per WhatsApp bestätigen
                </button>
              </>
            )}
          </section>
        )}

        {status === "sent" && (
          <section className="pay-box" role="status">
            <h2 style={{ fontSize: "var(--step-2)" }}>Danke für deine Bestellung</h2>
            <p>
              WhatsApp ist geöffnet. Sende die Nachricht ab. Sobald die Zahlung bestätigt ist, bekommst du deine
              Zugangsdaten an <strong>{order.email}</strong>.
            </p>
            <p>
              Nichts passiert?{" "}
              <a href={confirmUrl} target="_blank" rel="noopener">
                WhatsApp erneut öffnen
              </a>
            </p>
            <Link href={order.device === "anderes" ? "/anleitung" : `/anleitung/${order.device}`}>
              Schon mal die Anleitung für dein Gerät ansehen
            </Link>
          </section>
        )}
      </div>

      <aside className="box summary" aria-label="Bestellübersicht">
        <h2 style={{ fontSize: "var(--step-1)" }}>Deine Bestellung</h2>
        <dl>
          <dt>Paket</dt>
          <dd>{productLabel(product)}</dd>
          <dt>Gerät</dt>
          <dd>{deviceLabel(order.device)}</dd>
          <dt>E-Mail</dt>
          <dd>{order.email}</dd>
          <dt>Bestell-Nr.</dt>
          <dd>{order.id}</dd>
        </dl>
        <p className="total">
          <span>Gesamt</span>
          <span className="tabular">{formatEuro(product.price)}</span>
        </p>
        <p className="meta-line">Einmalige Zahlung, keine automatische Verlängerung.</p>
        {status === "review" && (
          <p className="meta-line" style={{ marginTop: "0.5rem" }}>
            <Link href="/preise">Paket ändern</Link>
          </p>
        )}
      </aside>
    </div>
  );
}
