"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import {
  deviceLabel,
  devices,
  getProduct,
  newOrderId,
  ORDER_KEY,
  paymentLabel,
  paymentMethods,
  productLabel,
  type Order,
  type PaymentId,
  type Product,
} from "@/lib/shop";
import { formatEuro, site, whatsappLink } from "@/lib/site";
import { track } from "@/lib/track";

type OpenArgs = { productId: string; device?: string };
const OrderContext = createContext<(args: OpenArgs) => void>(() => {});
export const useOrder = () => useContext(OrderContext);

/** Stellt das Bestell-Popup einmal für die ganze Seite bereit. */
export default function OrderProvider({ children }: { children: React.ReactNode }) {
  const [request, setRequest] = useState<OpenArgs | null>(null);
  const open = useCallback((args: OpenArgs) => setRequest({ ...args }), []);
  return (
    <OrderContext.Provider value={open}>
      {children}
      <OrderDialog request={request} onClose={() => setRequest(null)} />
    </OrderContext.Provider>
  );
}

export function whatsappOrderText(order: Order, product: Product, extra: string[] = []) {
  return [
    `Hallo ${site.supportName}, ich möchte ${product.months ? "ein IPTV-Abo" : "den IPTV-Test"} kaufen.`,
    "",
    `Paket: ${product.name} (${formatEuro(product.price)})`,
    `Gerät: ${deviceLabel(order.device)}`,
    `Zahlung: ${paymentLabel(order.payment)}`,
    `Name: ${order.name}`,
    `E-Mail: ${order.email}`,
    ...(order.phone ? [`WhatsApp: ${order.phone}`] : []),
    `Bestell-Nr.: ${order.id}`,
    ...extra,
  ].join("\n");
}

/** Schickt Daten an den Server, ohne auf die Antwort zu warten (überlebt auch einen Seitenwechsel). */
export function beacon(url: string, payload: object) {
  const body = JSON.stringify(payload);
  if (navigator.sendBeacon?.(url, new Blob([body], { type: "application/json" }))) return;
  fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body, keepalive: true }).catch(() => {});
}

/** Öffnet WhatsApp in neuem Tab; wenn der Browser das blockiert, im selben Tab. */
export function openWhatsapp(url: string) {
  const w = window.open(url, "_blank");
  if (w) w.opener = null;
  else window.location.href = url;
}

function OrderDialog({ request, onClose }: { request: OpenArgs | null; onClose: () => void }) {
  const ref = useRef<HTMLDialogElement>(null);
  const router = useRouter();
  const product = request ? getProduct(request.productId) : undefined;
  const [payment, setPayment] = useState<PaymentId | "">("");
  const [sentUrl, setSentUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (product && !dialog.open) {
      setPayment("");
      setSentUrl(null);
      setBusy(false);
      dialog.showModal();
      track("begin_checkout", {
        currency: "EUR",
        value: product.price,
        items: [{ item_id: product.id, item_name: product.name, price: product.price, quantity: 1 }],
      });
    }
    if (!product && dialog.open) dialog.close();
  }, [product]);

  if (!product) return <dialog ref={ref} className="order-dialog" onClose={onClose} />;

  const hint = paymentMethods.find((m) => m.id === payment)?.hint;
  const submitLabel = busy
    ? "Wird vorbereitet …"
    : payment === "crypto"
      ? `Weiter zur Krypto-Zahlung (${formatEuro(product.price)})`
      : payment
        ? `Per WhatsApp bestellen (${formatEuro(product.price)})`
        : `Weiter (${formatEuro(product.price)})`;

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!product || busy) return;
    const data = new FormData(e.currentTarget);
    const order: Order = {
      id: newOrderId(),
      productId: product.id,
      device: String(data.get("device")),
      payment: String(data.get("payment")) as PaymentId,
      name: String(data.get("name")).trim(),
      email: String(data.get("email")).trim(),
      phone: String(data.get("phone") ?? "").trim() || undefined,
      createdAt: new Date().toISOString(),
    };

    track("generate_lead", {
      currency: "EUR",
      value: product.price,
      lead_source: order.payment,
      items: [{ item_id: product.id, item_name: product.name, price: product.price, quantity: 1 }],
    });

    // Für das Admin-Dashboard speichern. Der Preis wird auf dem Server aus dem Paket bestimmt.
    const payload = {
      id: order.id,
      productId: order.productId,
      device: order.device,
      payment: order.payment,
      name: order.name,
      email: order.email,
      phone: order.phone,
      website: String(data.get("website") ?? ""),
    };

    if (order.payment === "crypto") {
      setBusy(true);
      try {
        const res = await fetch("/api/orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          const json = (await res.json()) as { token?: string };
          if (json.token) order.token = json.token;
        }
      } catch {
        /* Server nicht erreichbar: Bestellung läuft trotzdem über den Checkout und WhatsApp weiter */
      }
      sessionStorage.setItem(ORDER_KEY, JSON.stringify(order));
      ref.current?.close();
      router.push("/checkout");
      return;
    }

    beacon("/api/orders", payload);
    const url = whatsappLink(whatsappOrderText(order, product));
    openWhatsapp(url);
    setSentUrl(url);
  }

  return (
    <dialog
      ref={ref}
      className="order-dialog"
      aria-labelledby="order-title"
      onClose={onClose}
      onClick={(e) => {
        if (e.target === ref.current) ref.current?.close(); // Klick auf den Hintergrund
      }}
    >
      <div className="order-inner">
        <button type="button" className="order-close" aria-label="Schließen" onClick={() => ref.current?.close()}>
          <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true">
            <path d="M4 4l12 12M16 4L4 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>

        <p className="order-kicker">{product.popular ? "Beliebteste Wahl" : "Deine Bestellung"}</p>
        <h2 id="order-title">{productLabel(product)}</h2>
        <p className="order-sum">
          {product.months ? `Laufzeit ${product.name}, 1 Gerät` : `${product.hours} Stunden voller Zugang, 1 Gerät`}.
          Gesamtpreis <strong>{formatEuro(product.price)}</strong>, einmalig, keine automatische Verlängerung.
        </p>

        {sentUrl ? (
          <div className="order-done" role="status">
            <h3>WhatsApp ist geöffnet</h3>
            <p>
              Sende die vorbereitete Nachricht ab. Wir antworten mit dem Zahlungslink und schicken dir danach deine
              Zugangsdaten.
            </p>
            <p>
              Nichts passiert?{" "}
              <a href={sentUrl} target="_blank" rel="noopener">
                WhatsApp erneut öffnen
              </a>
            </p>
            <button type="button" className="btn btn-ghost" onClick={() => ref.current?.close()}>
              Schließen
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} key={`${product.id}-${request?.device ?? ""}`}>
            <div className="field-row">
              <div className="field">
                <label htmlFor="order-name">Name</label>
                <input id="order-name" name="name" type="text" autoComplete="name" required placeholder="Max Mustermann" />
              </div>
              <div className="field">
                <label htmlFor="order-email">E-Mail für Zugangsdaten</label>
                <input id="order-email" name="email" type="email" autoComplete="email" required placeholder="max@beispiel.de" />
              </div>
            </div>
            <div className="field">
              <label htmlFor="order-phone">WhatsApp-Nummer</label>
              <input
                id="order-phone"
                name="phone"
                type="tel"
                autoComplete="tel"
                required
                inputMode="tel"
                pattern="[+0-9 ()/-]{8,}"
                title="Bitte gib deine WhatsApp-Nummer mit Ländervorwahl ein, z. B. +49 170 1234567"
                placeholder="+49 170 1234567"
              />
            </div>

            <fieldset className="choices">
              <legend>Auf welchem Gerät schaust du?</legend>
              <div className="choice-grid">
                {devices.map((d) => (
                  <label key={d.id} className="choice">
                    <input type="radio" name="device" value={d.id} required defaultChecked={request?.device === d.id} />
                    <span>{d.label}</span>
                  </label>
                ))}
              </div>
            </fieldset>

            <fieldset className="choices">
              <legend>Wie möchtest du bezahlen?</legend>
              <div className="choice-grid is-3">
                {paymentMethods.map((m) => (
                  <label key={m.id} className="choice">
                    <input
                      type="radio"
                      name="payment"
                      value={m.id}
                      required
                      onChange={() => setPayment(m.id)}
                    />
                    <span>{m.label}</span>
                  </label>
                ))}
              </div>
              <p className="choice-hint" aria-live="polite">
                {hint ?? "Wähle eine Zahlungsart."}
              </p>
            </fieldset>

            {/* Honeypot gegen Spam-Bots: für Menschen unsichtbar */}
            <div aria-hidden="true" style={{ position: "absolute", left: "-9999px", width: 1, height: 1, overflow: "hidden" }}>
              <label>
                Website
                <input name="website" type="text" tabIndex={-1} autoComplete="off" />
              </label>
            </div>

            <button type="submit" className="btn btn-primary order-submit" disabled={busy} aria-busy={busy}>
              {submitLabel}
            </button>
            <p className="order-foot">
              Wir nutzen deine Angaben nur für deine Bestellung. Details in der{" "}
              <Link href="/datenschutz" onClick={() => ref.current?.close()}>
                Datenschutzerklärung
              </Link>
              .
            </p>
          </form>
        )}
      </div>
    </dialog>
  );
}
