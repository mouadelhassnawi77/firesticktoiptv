/**
 * Hero-Grafik: ein TV-Guide von 18:00 bis 22:00 Uhr in 15-Minuten-Rastern.
 * Die rote Linie steht auf 20:15 – Primetime in Deutschland.
 * Reines HTML/CSS, kein JavaScript, kein Bild: schnell für LCP und gut crawlbar.
 */
type Show = { title: string; start: number; end: number }; // Minuten ab 18:00

const NOW = 135; // 20:15
const TOTAL = 240;

const rows: { label: string; shows: Show[] }[] = [
  {
    label: "Sport",
    shows: [
      { title: "Vorberichte", start: 0, end: 90 },
      { title: "Fußball live", start: 90, end: 210 },
      { title: "Tore", start: 210, end: 240 },
    ],
  },
  {
    label: "News",
    shows: [
      { title: "Regional", start: 0, end: 60 },
      { title: "Magazin", start: 60, end: 135 },
      { title: "Politik-Talk", start: 135, end: 240 },
    ],
  },
  {
    label: "Filme",
    shows: [
      { title: "Abenteuerfilm", start: 0, end: 135 },
      { title: "Spielfilm-Premiere", start: 135, end: 240 },
    ],
  },
  {
    label: "Serien",
    shows: [
      { title: "Sitcom", start: 0, end: 60 },
      { title: "Klinikserie", start: 60, end: 135 },
      { title: "Krimi am Abend", start: 135, end: 240 },
    ],
  },
  {
    label: "Kinder",
    shows: [
      { title: "Zeichentrick", start: 0, end: 60 },
      { title: "Familienfilm", start: 60, end: 180 },
      { title: "Tierwelt", start: 180, end: 240 },
    ],
  },
  {
    label: "Doku",
    shows: [
      { title: "Die Alpen", start: 0, end: 90 },
      { title: "Geschichte", start: 90, end: 135 },
      { title: "Weltraum", start: 135, end: 240 },
    ],
  },
];

const q = (min: number) => min / 15 + 1; // Minuten -> Grid-Linie

export default function Epg() {
  return (
    <figure className="epg" aria-label="Beispiel aus dem TV-Guide: heute Abend um 20:15 Uhr" style={{ margin: 0 }}>
      <div className="epg-head" aria-hidden="true">
        <span>Heute</span>
        <div className="epg-times">
          <span>18:00</span>
          <span>19:00</span>
          <span>20:00</span>
          <span>21:00</span>
        </div>
      </div>
      <div className="epg-body">
        {rows.map((row, r) => (
          <div key={row.label} style={{ display: "contents" }}>
            <div className="epg-label" style={{ gridRow: r + 1 }}>
              {row.label}
            </div>
            <div className="epg-row" style={{ gridRow: r + 1 }}>
              {row.shows.map((s) => {
                const isNow = s.start <= NOW && NOW < s.end;
                return (
                  <div
                    key={s.title}
                    className={isNow ? "epg-show is-now" : "epg-show"}
                    style={{ gridColumn: `${q(s.start)} / ${q(s.end)}` }}
                  >
                    <span>{s.title}</span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        <div className="epg-now" aria-hidden="true">
          <div className="epg-now-line" style={{ left: `${(NOW / TOTAL) * 100}%` }} />
          <div className="epg-now-tag" style={{ left: `${(NOW / TOTAL) * 100}%` }}>
            20:15
          </div>
        </div>
      </div>
    </figure>
  );
}
