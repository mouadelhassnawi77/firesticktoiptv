import Link from "next/link";
import { LogoMark } from "./Logo";
import MobileNav from "./MobileNav";
import { mainNav, site, formatEuro } from "@/lib/site";
import { trial } from "@/lib/shop";

export default function Header() {
  return (
    <header className="site-header">
      <div className="wrap" style={{ position: "relative" }}>
        <Link href="/" className="brand" aria-label={`${site.name} Startseite`}>
          <LogoMark />
          {site.name}
        </Link>
        <nav className="nav-desktop" aria-label="Hauptnavigation">
          <ul>
            {mainNav.map((item) => (
              <li key={item.href}>
                <Link href={item.href}>{item.label}</Link>
              </li>
            ))}
          </ul>
        </nav>
        <Link href="/iptv-testen" className="btn btn-primary btn-small header-cta">
          Testen für {formatEuro(trial.price)}
        </Link>
        <MobileNav items={mainNav} />
      </div>
    </header>
  );
}
