import Breadcrumbs from "./Breadcrumbs";

/** Rahmen für Rechtstexte. Der gelbe Hinweis erscheint nur lokal (npm run dev), nie live. */
export default function LegalPage({
  title,
  path,
  children,
}: {
  title: string;
  path: string;
  children: React.ReactNode;
}) {
  return (
    <div className="wrap" style={{ paddingBottom: "clamp(3rem, 7vw, 5rem)" }}>
      <div className="page-head" style={{ paddingInline: 0 }}>
        <Breadcrumbs items={[{ name: title, path }]} />
        <h1>{title}</h1>
      </div>
      {process.env.NODE_ENV !== "production" && (
        <p className="dev-note">
          Vorlage: Platzhalter in src/lib/site.ts ersetzen und den Text vor dem Livegang rechtlich prüfen lassen.
        </p>
      )}
      <div className="prose">{children}</div>
    </div>
  );
}
