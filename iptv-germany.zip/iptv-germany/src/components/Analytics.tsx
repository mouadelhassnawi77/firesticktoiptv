"use client";

import Link from "next/link";
import Script from "next/script";
import { useEffect, useState } from "react";

/**
 * Google Analytics 4 with opt-in (DSGVO / § 25 TDDDG): nothing is loaded and no cookie is set
 * before the visitor clicks "Akzeptieren". The choice is stored locally and can be changed
 * any time via "Cookie-Einstellungen" in the footer.
 */
const GA_ID = process.env.NEXT_PUBLIC_GA_ID;
const KEY = "consent-analytics";
export const OPEN_CONSENT = "open-consent-settings";
type Choice = "granted" | "denied" | null;

function removeGaCookies() {
  const host = location.hostname;
  const domains = ["", host, `.${host}`, `.${host.split(".").slice(-2).join(".")}`];
  for (const c of document.cookie.split(";")) {
    const name = c.split("=")[0].trim();
    if (!name.startsWith("_ga") && !name.startsWith("_gid")) continue;
    for (const d of domains) {
      document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/${d ? `; domain=${d}` : ""}`;
    }
  }
}

export default function Analytics() {
  const [choice, setChoice] = useState<Choice | "loading">("loading");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let saved: Choice = null;
    try {
      const v = localStorage.getItem(KEY);
      saved = v === "granted" || v === "denied" ? v : null;
    } catch {
      /* storage blocked: ask every visit */
    }
    setChoice(saved);
    setOpen(saved === null);
    const reopen = () => setOpen(true);
    window.addEventListener(OPEN_CONSENT, reopen);
    return () => window.removeEventListener(OPEN_CONSENT, reopen);
  }, []);

  if (!GA_ID) return null;

  function decide(value: "granted" | "denied") {
    try {
      localStorage.setItem(KEY, value);
    } catch {
      /* ignore */
    }
    if (value === "denied" && choice === "granted") {
      // Withdrawal: stop GA and delete its cookies; reload so no script keeps running
      (window as unknown as Record<string, boolean>)[`ga-disable-${GA_ID}`] = true;
      removeGaCookies();
      location.reload();
      return;
    }
    setChoice(value);
    setOpen(false);
  }

  return (
    <>
      {choice === "granted" && (
        <>
          <Script src={`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`} strategy="afterInteractive" />
          <Script id="ga-init" strategy="afterInteractive">
            {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}window.gtag=gtag;gtag('js',new Date());gtag('config','${GA_ID}');`}
          </Script>
        </>
      )}
      {open && choice !== "loading" && (
        <div className="consent" role="dialog" aria-labelledby="consent-title" aria-live="polite">
          <p id="consent-title" className="consent-title">
            Cookies für Statistik
          </p>
          <p>
            Mit deiner Zustimmung nutzen wir Google Analytics, um zu verstehen, wie unsere Seite genutzt wird. Dabei werden
            Cookies gesetzt und Daten an Google übertragen, auch in die USA. Du kannst deine Wahl jederzeit über
            „Cookie-Einstellungen“ im Seitenfuß ändern. Mehr in der <Link href="/datenschutz">Datenschutzerklärung</Link>.
          </p>
          <div className="consent-actions">
            <button type="button" className="btn btn-ghost" onClick={() => decide("denied")}>
              Ablehnen
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => decide("granted")}>
              Akzeptieren
            </button>
          </div>
        </div>
      )}
    </>
  );
}
