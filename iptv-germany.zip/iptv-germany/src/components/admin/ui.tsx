import { statusLabel } from "@/lib/orders";
import { site } from "@/lib/site";

/** Admin UI is English; dates and times are shown in Berlin time. Messages to customers stay German. */
const dt = new Intl.DateTimeFormat("en-GB", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Berlin" });
const d = new Intl.DateTimeFormat("en-GB", { dateStyle: "medium", timeZone: "Europe/Berlin" });
const eur = new Intl.NumberFormat("en-GB", { style: "currency", currency: "EUR" });
const eurShort = new Intl.NumberFormat("en-GB", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });

export const fmtDateTime = (v: Date | null) => (v ? dt.format(new Date(v)) : "–");
export const fmtDate = (v: Date | null) => (v ? d.format(new Date(v)) : "–");
export const fmtCents = (cents: number) => eur.format(cents / 100);
export const fmtEuro = (value: number) => eur.format(value);
export const fmtEuroShort = (value: number) => eurShort.format(value);
export const fmtNum = (value: number, digits = 0) => value.toLocaleString("en-GB", { maximumFractionDigits: digits });

const DEVICES: Record<string, string> = {
  "fire-tv-stick": "Fire TV Stick",
  "smart-tv": "Smart TV (Samsung, LG)",
  android: "Android / Google TV",
  "iphone-ipad": "iPhone, iPad, Apple TV",
  "mag-box": "MAG box",
  "windows-mac": "PC / Mac",
  anderes: "Other device",
};
const PAYMENTS: Record<string, string> = {
  crypto: "Crypto (BTC, USDT)",
  card: "Credit / debit card",
  paypal: "PayPal",
};
const PRODUCTS: Record<string, string> = {
  "test-24h": "24h trial",
  "3-monate": "3 months",
  "6-monate": "6 months",
  "12-monate": "12 months",
};

export const deviceLabel = (id: string) => DEVICES[id] ?? id;
export const paymentLabel = (id: string) => PAYMENTS[id] ?? id;
export const paymentShort = (id: string) => (id === "crypto" ? "Crypto" : id === "paypal" ? "PayPal" : "Card");
/** Package name in English (DB stores the German name at order time as a snapshot) */
export const productLabel = (id: string, fallback?: string) => PRODUCTS[id] ?? fallback ?? id;

export function StatusBadge({ status }: { status: string }) {
  return <span className={`badge badge-${status}`}>{statusLabel(status)}</span>;
}

/** Phone number for wa.me: digits only, a leading 0 is read as a German number (+49). */
export function waNumber(phone: string | null) {
  if (!phone) return null;
  let digits = phone.replace(/[^\d+]/g, "");
  if (digits.startsWith("+")) digits = digits.slice(1);
  else if (digits.startsWith("00")) digits = digits.slice(2);
  else if (digits.startsWith("0")) digits = `49${digits.slice(1)}`;
  return digits.length >= 8 ? digits : null;
}

export function waToCustomer(phone: string | null, text: string) {
  const n = waNumber(phone);
  return n ? `https://wa.me/${n}?text=${encodeURIComponent(text)}` : null;
}

/*
 * Customer-facing WhatsApp texts stay in German (the customers are in Germany) and are always
 * sent as the brand: "IPTV Germany Support", never a personal name.
 */
const SIGNATURE = `\n\nViele Grüße\n${site.supportName}`;

/** Direct WhatsApp chat with the customer, with a short greeting about the order */
export function waChat(o: { phone: string | null; name: string; id: string; product_name: string }) {
  return waToCustomer(
    o.phone,
    `Hallo ${o.name},\n\nhier ist der ${site.supportName} zu deiner Bestellung ${o.id} (${o.product_name}).${SIGNATURE}`
  );
}

export const templates = {
  payment: (name: string, id: string, product: string, price: string) =>
    `Hallo ${name},\n\nhier ist der ${site.supportName}. Danke für deine Bestellung ${id} (${product}, ${price}). Hier ist dein Zahlungslink:\n\n[Link einfügen]${SIGNATURE}`,
  access: (name: string, id: string) =>
    `Hallo ${name},\n\nhier ist der ${site.supportName}. Deine Zahlung für ${id} ist eingegangen. Hier sind deine Zugangsdaten:\n\nServer: \nBenutzername: \nPasswort: \n\nAnleitung: ${site.url}/anleitung${SIGNATURE}`,
  renewal: (name: string, expires: string) =>
    `Hallo ${name},\n\nhier ist der ${site.supportName}. Dein IPTV-Abo läuft am ${expires} ab. Möchtest du verlängern? Das Jahresabo ist am günstigsten: ${site.url}/preise/12-monate${SIGNATURE}`,
};

/** German date for customer messages */
export const fmtDateDe = (v: Date | null) =>
  v ? new Intl.DateTimeFormat("de-DE", { dateStyle: "medium", timeZone: "Europe/Berlin" }).format(new Date(v)) : "";
