import Link from "next/link";
import { guides } from "@/lib/guides";

export default function DeviceList({ exclude }: { exclude?: string }) {
  return (
    <ul className="device-list">
      {guides
        .filter((g) => g.slug !== exclude)
        .map((g) => (
          <li key={g.slug}>
            <Link href={`/anleitung/${g.slug}`}>
              {g.device}
              <span>Anleitung</span>
            </Link>
          </li>
        ))}
    </ul>
  );
}
